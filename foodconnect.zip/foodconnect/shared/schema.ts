import { z } from "zod";

// User Roles
export type UserRole = "donor" | "recipient" | "volunteer" | "admin";

// Location Schema
export const locationSchema = z.object({
  lat: z.number(),
  lng: z.number(),
});

export type Location = z.infer<typeof locationSchema>;

// User Schema
export const userSchema = z.object({
  id: z.string(),
  email: z.string().email(),
  name: z.string().min(2),
  phone: z.string().min(10),
  role: z.enum(["donor", "recipient", "volunteer", "admin"]),
  status: z.enum(["active", "suspended", "flagged"]).default("active"),
  address: z.string().optional(),
  organization: z.string().optional(),
  profileImage: z.string().optional(),
  location: locationSchema.optional(),
  createdAt: z.date(),
  lastActive: z.date().optional(),
});

export const insertUserSchema = userSchema.omit({
  id: true,
  createdAt: true,
});

export type User = z.infer<typeof userSchema>;
export type InsertUser = z.infer<typeof insertUserSchema>;

// Donation Schema
export const donationSchema = z.object({
  id: z.string(),
  donorId: z.string(),
  donorName: z.string(),
  donorPhone: z.string(),
  foodType: z.string().min(3),
  quantity: z.string(),
  description: z.string().optional(),
  location: z.string(),
  address: z.string(),
  latitude: z.number().optional(),
  longitude: z.number().optional(),
  expiresAt: z.date(),
  status: z.enum(["available", "pending", "assigned", "completed", "cancelled"]).default("available"),
  createdAt: z.date(),
  assignedTo: z.string().optional(), // recipient ID
  assignedRecipientName: z.string().optional(),
  volunteerId: z.string().optional(),
  volunteerName: z.string().optional(),
});

export const insertDonationSchema = donationSchema.omit({
  id: true,
  createdAt: true,
  status: true,
});

export type Donation = z.infer<typeof donationSchema>;
export type InsertDonation = z.infer<typeof insertDonationSchema>;

// Delivery Request Schema
// Delivery Request Schema
export const deliveryRequestSchema = z.object({
  id: z.string(),
  donationId: z.string(),

  // 🔹 Donor Info
  donorId: z.string(),
  donorName: z.string(),
  donorPhone: z.string(),
  donorAddress: z.string(),
  donorLatitude: z.number(),
  donorLongitude: z.number(),
  // 🔹 Recipient Info
  recipientId: z.string(),
  recipientName: z.string(),
  recipientPhone: z.string(),
  recipientAddress: z.string(),
  recipientLatitude: z.number(),
  recipientLongitude: z.number(),

  // 🔹 Volunteer Info
  volunteerId: z.string().optional(),
  volunteerName: z.string().optional(),
  volunteerPhone: z.string().optional(),

  // 🔹 Status & Meta
  status: z.enum(["pending", "accepted", "in_progress", "completed", "cancelled"]).default("pending"),
  createdAt: z.date(),
  acceptedAt: z.date().optional(),
  completedAt: z.date().optional(),
  estimatedTime: z.string().optional(),
  distance: z.string().optional(),
  notes: z.string().optional(),
});


export const insertDeliveryRequestSchema = deliveryRequestSchema.omit({
  id: true,
  createdAt: true,
  status: true,
});

export type DeliveryRequest = z.infer<typeof deliveryRequestSchema>;
export type InsertDeliveryRequest = z.infer<typeof insertDeliveryRequestSchema>;

// Volunteer Stats Schema
export const volunteerStatsSchema = z.object({
  volunteerId: z.string(),
  activeDeliveries: z.number().default(0),
  completedDeliveries: z.number().default(0),
  distanceTraveled: z.number().default(0), // in km
  mealsDelivered: z.number().default(0),
  lastUpdated: z.date(),
});

export type VolunteerStats = z.infer<typeof volunteerStatsSchema>;

// Donor Stats Schema
export const donorStatsSchema = z.object({
  donorId: z.string(),
  totalDonations: z.number().default(0),
  activeListings: z.number().default(0),
  completedDonations: z.number().default(0),
  impactScore: z.number().default(0),
  lastUpdated: z.date(),
});

export type DonorStats = z.infer<typeof donorStatsSchema>;

// Recipient Stats Schema
export const recipientStatsSchema = z.object({
  recipientId: z.string(),
  nearbyDonations: z.number().default(0),
  requestedItems: z.number().default(0),
  receivedItems: z.number().default(0),
  lastUpdated: z.date(),
});

export type RecipientStats = z.infer<typeof recipientStatsSchema>;

// Fraud Alert Schema
export const fraudAlertSchema = z.object({
  id: z.string(),
  userId: z.string(),
  userName: z.string(),
  userEmail: z.string(),
  reason: z.string(),
  severity: z.enum(["low", "medium", "high"]),
  status: z.enum(["open", "investigating", "resolved"]).default("open"),
  createdAt: z.date(),
  resolvedAt: z.date().optional(),
  notes: z.string().optional(),
});

export const insertFraudAlertSchema = fraudAlertSchema.omit({
  id: true,
  createdAt: true,
  status: true,
});

export type FraudAlert = z.infer<typeof fraudAlertSchema>;
export type InsertFraudAlert = z.infer<typeof insertFraudAlertSchema>;

// Platform Stats Schema (for Admin Dashboard)
export const platformStatsSchema = z.object({
  totalUsers: z.number().default(0),
  activeDonations: z.number().default(0),
  completedDeliveries: z.number().default(0),
  fraudAlertsCount: z.number().default(0),
  lastUpdated: z.date(),
});

export type PlatformStats = z.infer<typeof platformStatsSchema>;
