# FoodConnect Design Guidelines

## Design Approach

**Selected Approach**: Hybrid System with Modern SaaS Aesthetics

Drawing inspiration from **Linear** (clean dashboards), **Notion** (multi-role interfaces), and **Uber** (real-time tracking) to create a professional, trust-building social impact platform. The design balances utility-focused dashboards with visually appealing public-facing pages that convey credibility and social mission.

**Core Principles**:
- **Trust & Authenticity**: Professional, polished design that looks like a legitimate social enterprise
- **Role Clarity**: Distinct visual hierarchies for Donor, Recipient, Volunteer, and Admin interfaces
- **Real-time Transparency**: Live updates and tracking information prominently displayed
- **Accessibility First**: WCAG AA compliant with clear contrast and readable typography

---

## Typography

**Font Stack**: 
- **Primary**: Inter (via Google Fonts CDN) - for UI elements, dashboards, forms
- **Display**: Poppins (via Google Fonts CDN) - for headings, hero sections, marketing content

**Hierarchy**:
- **Hero Headlines**: text-5xl md:text-6xl lg:text-7xl, font-bold, Poppins
- **Section Headings**: text-3xl md:text-4xl, font-semibold, Poppins
- **Subsection Headings**: text-xl md:text-2xl, font-semibold, Inter
- **Body Text**: text-base md:text-lg, font-normal, Inter, leading-relaxed
- **Dashboard Labels**: text-sm, font-medium, Inter, tracking-wide, uppercase
- **Data/Stats**: text-2xl md:text-3xl, font-bold, tabular-nums for consistency

---

## Layout System

**Spacing Primitives**: Use Tailwind units of **2, 4, 6, 8, 12, 16, 20** for consistent rhythm

**Container Strategy**:
- **Marketing Pages**: max-w-7xl mx-auto px-4 sm:px-6 lg:px-8
- **Dashboard Content**: max-w-screen-2xl mx-auto px-6 lg:px-8
- **Forms & Cards**: max-w-2xl for focused content
- **Text Content**: max-w-prose for optimal readability

**Grid Patterns**:
- **Feature Sections**: grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8
- **Dashboard Cards**: grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6
- **Stats Display**: grid-cols-2 md:grid-cols-4 gap-4

**Vertical Rhythm**:
- **Hero Sections**: py-20 md:py-28 lg:py-32
- **Content Sections**: py-16 md:py-20 lg:py-24
- **Dashboard Sections**: py-8 md:py-12
- **Card Padding**: p-6 md:p-8

---

## Component Library

### Navigation
**Public Navigation**: Fixed top navigation with logo left, menu center, CTA buttons right. Height h-16 with backdrop-blur-md for glassmorphism effect when scrolling. Mobile: hamburger menu with full-screen overlay.

**Dashboard Navigation**: Persistent left sidebar (w-64) on desktop with role-based menu items, user profile at bottom. Top bar shows current page title, notifications bell icon, and user avatar. Mobile: collapsible drawer triggered by menu icon.

### Cards & Containers
**Donation Cards**: Rounded-lg border with shadow-md on hover. Contains food image placeholder (aspect-video), food type badge, quantity, expiry countdown timer, location with map pin icon, and action button. Use gap-4 for internal spacing.

**Dashboard Stats Cards**: Rounded-xl with gradient border effect. Large number (text-3xl font-bold), label below (text-sm uppercase tracking-wide), trend indicator with arrow icon and percentage.

**Profile Cards (Team)**: Circular avatar with initials (w-24 h-24 text-2xl font-semibold), name (text-xl font-bold), title (text-sm), bio (text-base leading-relaxed). Centered layout with mx-auto.

### Forms & Inputs
**Text Inputs**: Rounded-lg border-2 with focus ring. Height h-12 for text inputs, h-32 for textareas. Label above with text-sm font-medium mb-2. Error states show border-red-500 with error message text-sm below.

**Select Dropdowns**: Same styling as text inputs with chevron-down icon. Custom dropdown menu with max-h-60 overflow-y-auto.

**Radio Buttons & Checkboxes**: Custom styled with rounded-full for radio, rounded for checkbox. Active state shows checkmark icon. Grouped with gap-4 and clear labels.

**OTP Input**: Six separate input boxes (w-12 h-12 text-center text-xl) with gap-2, auto-focus progression.

### Buttons
**Primary CTA**: Rounded-lg px-6 py-3 text-base font-semibold with shadow-lg. Hover lifts with -translate-y-1 transition.

**Secondary**: Outlined version with border-2, transparent background.

**Icon Buttons**: w-10 h-10 rounded-full for actions like notifications, profile menu.

**Floating Action**: Fixed bottom-right (bottom-8 right-8) rounded-full w-14 h-14 with shadow-2xl for quick donation creation.

### Data Display
**Tables**: Rounded-lg border with striped rows. Header with sticky position, font-semibold, uppercase text-xs. Cells with py-4 px-6. Mobile: transform to stacked cards.

**Status Badges**: Rounded-full px-3 py-1 text-xs font-medium inline-flex items-center gap-1 with dot indicator. Different treatments for Active, Pending, Completed, Expired states.

**Progress Indicators**: Linear progress bar (h-2 rounded-full) showing delivery status. Stepped progress for multi-stage processes with connected dots and lines.

### Maps & Tracking
**Map Container**: Rounded-xl overflow-hidden shadow-xl with min-h-96 for embedded Google Maps. Overlay cards positioned absolute with semi-transparent background and backdrop-blur.

**Live Location Card**: Shows volunteer avatar, name, current location, ETA with countdown timer, and route summary. Positioned top-4 left-4 on map with rounded-lg shadow-lg.

**Route Info Panel**: Bottom sheet on mobile, right sidebar (w-80) on desktop showing step-by-step directions, distance, time estimates.

### Notifications
**Toast Notifications**: Fixed top-right stack with slide-in animation. Rounded-lg shadow-xl with icon, title, message, and dismiss button. Auto-dismiss after 5 seconds.

**Notification Bell**: Badge counter on bell icon in nav. Dropdown panel showing recent notifications with mark-as-read functionality.

### Modals & Overlays
**Dialog Modals**: Centered overlay with backdrop blur. Content container max-w-lg rounded-xl shadow-2xl. Header with title and close button, body with p-6, footer with action buttons aligned right.

**Confirmation Dialogs**: Compact version for destructive actions with warning icon, clear message, and Cancel/Confirm buttons.

---

## Page-Specific Layouts

### Landing Page
**Hero Section** (h-screen): Full-viewport gradient background, centered content with headline (max-w-4xl), subheadline, two-button CTA group (Get Started + Learn More), and hero illustration/image (aspect-video) positioned right on desktop, below on mobile. Includes floating stats cards showing impact metrics.

**How It Works**: Three-column grid with numbered steps. Each card has large number badge, icon, title, description. Connected with decorative lines on desktop.

**Impact Statistics**: Full-width banner with four-column grid showing donated meals, active volunteers, partner organizations, food saved. Large numbers with countup animation on scroll.

**Featured Donations**: Horizontal scrollable carousel of donation cards with "View All" CTA.

**Testimonials**: Two-column grid with quoted text, user avatar (initials), name, and role.

**Call-to-Action Section**: Centered content with compelling headline, supporting text, and prominent role-selection buttons (Become a Donor, Volunteer, Request Food).

### About Us Page
**Team Section**: Three-column grid of team member cards with circular initial avatars (BV, NV, AR), full names, titles (Founder & CEO, CTO, COO), and bio paragraphs. No photos - professional branded circles with gradient backgrounds.

**Mission Statement**: Single column max-w-3xl with large text-2xl leading-relaxed.

**Values/Goals**: Grid of value cards with icons representing sustainability, community, technology.

### Dashboard Layouts

**Donor Dashboard**: 
- Stats row: Total Donations, Active Listings, Completed, Impact Score
- Quick Action: "Create New Donation" prominent button
- Main content: Table of active donations with edit/delete actions
- Sidebar: Upcoming pickups, recent requests

**Recipient Dashboard**:
- Stats row: Requests Made, Food Received, Saved Meals
- Map view: Available donations with markers
- Filters: Food type, distance radius, expiry time
- List view: Donation cards with "Request" button

**Volunteer Dashboard**:
- Active deliveries: Current assignment with live map
- Available deliveries: List of pickup requests to accept
- Delivery history: Past completions with ratings
- Stats: Total deliveries, distance traveled, impact

**Admin Dashboard**:
- Overview stats: Total users by role, daily donations, fraud flags
- User management table: Search, filter, view details, suspend/delete actions
- Donation monitoring: Real-time feed of new donations and requests
- Analytics charts: Line graphs for trends, bar charts for comparisons

---

## Images

**Hero Image**: Large, professional photograph of diverse volunteers distributing food packages to recipients. Should convey warmth, community, and hope. Positioned right side on desktop (w-1/2), full-width on mobile. Use aspect-video with object-cover.

**How It Works Icons**: Use Heroicons library for simple line icons representing each step (create donation, volunteer accepts, delivery tracked).

**Team Avatars**: NO PHOTOS. Use circular gradients with white initials (BV, NV, AR) - professional and clean.

**Donation Placeholders**: When no food image provided, use gradient rectangles with food category icon (utensils for meals, bread for bakery, etc.).

**Feature Section Graphics**: Abstract geometric shapes and patterns suggesting connection, flow, and impact - can use CSS gradients and shapes instead of images.

**Contact Page**: Optional: Illustration of people using mobile app to coordinate food donation (clean vector style).

This design creates a professional, trustworthy platform that looks like a legitimate social enterprise application, not an AI-generated mockup. Every element serves the core mission of reducing food waste while building user confidence through polished, intentional design choices.