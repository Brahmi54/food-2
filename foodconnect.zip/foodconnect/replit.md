# FoodConnect - Food Waste Reduction Platform

## Project Overview
FoodConnect is a full-stack web application that connects food donors (restaurants, businesses), volunteers (delivery coordinators), and recipients (shelters, individuals) to reduce food waste. The platform features multi-role authentication, real-time delivery tracking with Google Maps, and a professional UI built with React, Firebase, and Google Maps API.

## Tech Stack
- **Frontend**: React, TypeScript, Tailwind CSS, Wouter (routing)
- **Backend**: Firebase Authentication (with browserLocalPersistence), Firestore Database
- **Maps**: Google Maps API (@react-google-maps/api)
- **UI Components**: Shadcn UI (Radix UI primitives)
- **Build Tool**: Vite
- **Package Manager**: npm

## Architecture

### Authentication & User Management
- **Firebase Authentication** with email/password and built-in email verification
- **Firebase Email Verification** using sendEmailVerification (verification link sent to user's email)
- **Role-based access control** (donor, recipient, volunteer, admin)
- **Protected routes** with automatic redirection based on verification status
- **Admin Setup** at /setup-admin for one-time admin account creation (admins bypass email verification)
- **Secure password reset** functionality using Firebase's sendPasswordResetEmail

#### Email Verification Flow
1. User fills signup form and clicks "Register"
2. Account created in Firebase Authentication
3. **Firebase sends verification email** with clickable link to user's inbox
4. **User redirected to /verify-email page** with instructions
5. User checks email inbox and clicks verification link
6. Firebase automatically marks account as verified
7. User returns to /verify-email page and clicks "I've Verified My Email"
8. Upon successful verification:
   - Firebase's `emailVerified` property set to true
   - Success popup shown: "Email Verified! 🎉"
   - **Automatic redirect to role-based dashboard** (/dashboard/donor, /dashboard/recipient, etc.)
9. Resend verification email button available with 60-second countdown timer

#### Admin Account Setup
- Special route: `/setup-admin` for one-time admin creation
- Credentials: `admin@foodconnect.com` / `admin@123`
- Admin accounts bypass email verification requirement
- If admin already exists, updates role to admin
- Direct dashboard access without email verification

### Data Models (Firestore Collections)
1. **users**: User profiles with role, contact info, and status
2. **donations**: Food donations with location, quantity, expiry time
3. **deliveryRequests**: Delivery coordination between donors, recipients, and volunteers
4. **donorStats**: Donor performance metrics
5. **recipientStats**: Recipient activity tracking
6. **volunteerStats**: Volunteer delivery statistics
7. **fraudAlerts**: Admin fraud detection alerts
8. **platformStats**: Global platform statistics

### Key Features by Role

#### Donors
- Create food donations with details (type, quantity, location, expiry)
- Track donation status (available, pending, assigned, completed, cancelled)
- View real-time statistics (total donations, active listings, completed, impact score)
- Real-time updates when donations are requested
- **Nearby volunteers map** showing live volunteer locations for better coordination

#### Recipients
- Browse available food donations with search functionality
- Request donations which creates delivery requests
- View requested and received donations
- Track delivery status in real-time
- Statistics: nearby donations, requested items, received items
- **Nearby volunteers map** showing live volunteer locations for delivery visibility

#### Volunteers
- View and accept pending delivery requests
- Track active deliveries with Google Maps route visualization
- Start and complete deliveries
- Real-time map showing pickup and dropoff locations with directions
- Statistics: active deliveries, completed deliveries, distance traveled, meals delivered
- **Real-time location tracking** with browser geolocation API (updates every 30 seconds)
- Live location map showing current position on Google Maps

#### Admins
- User management (view all users, block/unblock accounts)
- **Block/Unblock Users**: Red "Block" button for active users, blue "Unblock" button for suspended users
- **CSV Export**: Export all users to CSV file with name, email, role, status, phone, and activity data
- **CSV Import**: Upload CSV files for bulk data import (placeholder UI ready)
- Platform statistics dashboard (total users, active donations, completed deliveries, fraud alerts)
- Fraud alert monitoring and resolution
- Search and filter users by name, email, or role
- View user activity metrics by role (donations, requests, deliveries)

## Project Structure

```
client/
├── src/
│   ├── components/
│   │   ├── ui/              # Shadcn UI components
│   │   ├── DonationCard.tsx # Reusable donation display card
│   │   ├── StatCard.tsx     # Statistics display card
│   │   ├── DeliveryMap.tsx  # Google Maps integration
│   │   ├── VolunteerLocationTracker.tsx # Real-time location tracking
│   │   ├── NearbyVolunteersMap.tsx # Map showing nearby volunteers
│   │   └── ProtectedRoute.tsx # Route access control
│   ├── contexts/
│   │   └── AuthContext.tsx  # Global authentication state
│   ├── lib/
│   │   ├── firebase.ts      # Firebase configuration
│   │   ├── auth.ts          # Authentication helpers
│   │   ├── firestore.ts     # Firestore CRUD operations
│   │   ├── storage.ts       # Firebase Storage operations (profile images)
│   │   └── queryClient.ts   # React Query setup
│   ├── pages/
│   │   ├── Home.tsx
│   │   ├── About.tsx
│   │   ├── Contact.tsx
│   │   ├── Login.tsx        # Email/password login with forgot password
│   │   ├── Register.tsx     # Registration with Firebase email verification
│   │   ├── VerifyEmail.tsx  # Email verification instructions page
│   │   ├── SetupAdmin.tsx   # One-time admin setup
│   │   ├── Profile.tsx      # User profile with image upload
│   │   ├── DonorDashboard.tsx
│   │   ├── RecipientDashboard.tsx
│   │   ├── VolunteerDashboard.tsx
│   │   └── AdminDashboard.tsx
│   └── App.tsx              # Main app with routing
shared/
└── schema.ts                # TypeScript types and Zod schemas
```

## Environment Variables (Secrets)
Required secrets configured in Replit:
- `VITE_FIREBASE_API_KEY` - Firebase API key for authentication
- `VITE_FIREBASE_AUTH_DOMAIN` - Firebase authentication domain
- `VITE_FIREBASE_PROJECT_ID` - Firebase project identifier
- `VITE_FIREBASE_STORAGE_BUCKET` - Firebase storage bucket
- `VITE_FIREBASE_MESSAGING_SENDER_ID` - Firebase messaging sender ID
- `VITE_FIREBASE_APP_ID` - Firebase application ID
- `VITE_GOOGLE_MAPS_API_KEY` - Google Maps API for delivery tracking
- `SESSION_SECRET` - Express session secret for secure session management

## Design System
- **Primary Color**: Royal Blue (#4169E1)
- **Secondary Color**: Bright Cyan (#00BFFF)
- **Accent Color**: Purple (#9333EA)
- **Fonts**: Inter (body), Poppins (headings)
- **Logo**: "FoodConnect" with cyan accent dot

## Team
- **Brahmaiah Vallepu** - Founder & CEO
- **Naga Sri Varsha Mathamsetti** - CTO
- **Sri Anjali Reddy Guduri** - COO

## Contact Information
- **Phone**: +91 9123456780
- **Address**: 47/22-2, road no 5, Jubilee Hills, Hyderabad, Telangana 500096

## Development Status
✅ Complete frontend prototype with all pages and dashboards
✅ Firebase Authentication with email/password
✅ **Firebase Built-in Email Verification** using sendEmailVerification (verification link sent via email)
✅ **VerifyEmail Page** with resend functionality and countdown timer
✅ **Admin Setup Page** at /setup-admin (admins bypass email verification)
✅ **Admin Email Verification Bypass**: Admins login directly without email verification
✅ **Password Reset Functionality**: Forgot password feature using Firebase's sendPasswordResetEmail
✅ Firestore database integration for all data models
✅ Real-time data subscriptions across all dashboards
✅ Google Maps integration for delivery tracking
✅ Role-based access control and protected routes
✅ **User Block/Unblock**: Admins can block (suspend) and unblock (activate) users
✅ **CSV Export**: Export user data to CSV file (name, email, role, status, phone, activity)
✅ **CSV Import UI**: File upload interface ready for bulk data import
✅ User management and fraud detection (Admin)
✅ Complete CRUD operations for donations and deliveries
✅ **User Profile Management**: Full profile editing with Firebase Storage image uploads
✅ **Real-time Volunteer Location Tracking**: Browser geolocation API with automatic Firestore updates
✅ **Nearby Volunteers Map**: Live Google Maps showing active volunteers for donors and recipients
✅ **Critical Security Fix**: Proper geolocation watcher cleanup to prevent location leaks after logout

## Running the Application
The workflow "Start application" runs `npm run dev` which starts:
- Express server for the backend
- Vite development server for the frontend
- Single port deployment (5000) with automatic routing

## Required Manual Configuration
⚠️ **Firestore Security Rules** - Update in [Firebase Console](https://console.firebase.google.com):
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    function isAdmin() {
      return request.auth != null && 
             exists(/databases/$(database)/documents/users/$(request.auth.uid)) &&
             get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin';
    }
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
      allow read, write: if isAdmin();
    }
    match /donations/{donationId} {
      allow read, write: if request.auth != null;
    }
    match /deliveryRequests/{requestId} {
      allow read, write: if request.auth != null;
    }
    match /fraudAlerts/{alertId} {
      allow read, write: if isAdmin();
    }
    match /{path=**}/Stats/{statId} {
      allow read, write: if request.auth != null;
    }
  }
}
```

⚠️ **Firestore Composite Indexes** - Create the following composite indexes in [Firebase Console](https://console.firebase.google.com):

### Required Indexes

1. **fraudAlerts Collection**
   - Fields: `status` (Ascending), `createdAt` (Descending)
   - Purpose: Admin dashboard fraud alert queries

2. **deliveryRequests Collection** (Multiple indexes needed)
   - Index 1: `volunteerId` (Ascending), `status` (Ascending), `createdAt` (Descending)
     - Purpose: Volunteer dashboard - active deliveries query
   - Index 2: `status` (Ascending), `createdAt` (Descending)
     - Purpose: Volunteer dashboard - pending deliveries query
   - Index 3: `recipientId` (Ascending), `createdAt` (Descending)
     - Purpose: Recipient dashboard - delivery requests query

3. **donations Collection**
   - Index 1: `donorId` (Ascending), `createdAt` (Descending)
     - Purpose: Donor dashboard - donations query
   - Index 2: `status` (Ascending), `createdAt` (Descending)
     - Purpose: Recipient dashboard - available donations query

**Note**: Firebase Console will provide direct links to create these indexes when you encounter "index required" errors in the browser console. Click those links to auto-configure the indexes.

## Next Steps (Future Enhancements)
- **Complete CSV Import**: Implement Firebase Auth account creation for bulk user import
- Email notifications for delivery updates
- SMS verification backup option (Twilio integration)
- Push notifications for mobile
- Analytics dashboard with charts (Recharts)
- Advanced fraud detection algorithms
- Multi-language support (i18n)
- Mobile app (React Native)
- Rate limiting for verification email requests
- Account deletion and data export (GDPR compliance)

## Notes
- All Firebase secrets are securely stored in Replit Secrets
- No mock data in production; all data comes from Firestore
- Real-time updates without page refresh using Firestore real-time listeners
- Firebase handles email verification automatically with secure links
- Admin account created via /setup-admin (bypasses email verification)
- Firebase's built-in email verification uses Firebase's email templates
- Responsive design for mobile, tablet, and desktop
- Accessibility features with proper ARIA labels and semantic HTML
- Email verification links expire based on Firebase's default security settings
