import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {

  // Setup admin account (one-time use endpoint)
  app.post("/api/setup-admin", async (req, res) => {
    try {
      const { secretKey } = req.body;
      
      // Simple security check - require a secret key
      if (secretKey !== "foodconnect-admin-setup-2025") {
        return res.status(403).json({ error: "Unauthorized" });
      }

      const adminData = {
        email: "admin@foodconnect.com",
        password: "admin@123",
        userId: "ADMIN_SETUP_REQUIRED", // Will be replaced by actual Firebase UID
        name: "Admin User",
        phone: "+91 9123456780",
      };

      res.json({ 
        success: true,
        message: "Admin setup data prepared. You need to register manually with these credentials and then update the role in Firestore.",
        data: adminData
      });
    } catch (error: any) {
      console.error("Error setting up admin:", error);
      res.status(500).json({ error: error.message || "Failed to setup admin" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
