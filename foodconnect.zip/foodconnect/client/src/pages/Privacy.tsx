import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function Privacy() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <section className="py-16 md:py-20 lg:py-24">
          <div className="container mx-auto max-w-4xl px-4">
            <div className="mb-12">
              <h1 className="font-display font-bold text-4xl md:text-5xl mb-4">Privacy Policy</h1>
              <p className="text-muted-foreground">Last updated: {new Date().toLocaleDateString()}</p>
            </div>

            <div className="prose prose-gray dark:prose-invert max-w-none space-y-8">
              <section>
                <h2 className="font-display font-bold text-2xl mb-4">Introduction</h2>
                <p className="text-muted-foreground leading-relaxed">
                  FoodConnect ("we", "our", or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our platform.
                </p>
              </section>

              <section>
                <h2 className="font-display font-bold text-2xl mb-4">Information We Collect</h2>
                <div className="space-y-4">
                  <div>
                    <h3 className="font-semibold text-lg mb-2">Personal Information</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      When you register on FoodConnect, we collect: name, email address, phone number, password (encrypted), and role selection (donor, volunteer, or recipient).
                    </p>
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-2">Location Data</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      For donors and recipients, we collect location information for pickup and delivery coordination. For volunteers, we track real-time location during active deliveries for transparency.
                    </p>
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-2">Usage Information</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      We collect information about your interactions with the platform, including donations created, requests made, and deliveries completed.
                    </p>
                  </div>
                </div>
              </section>

              <section>
                <h2 className="font-display font-bold text-2xl mb-4">How We Use Your Information</h2>
                <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                  <li>To create and manage your account</li>
                  <li>To facilitate food donation coordination between users</li>
                  <li>To provide real-time delivery tracking</li>
                  <li>To send notifications about donation status and requests</li>
                  <li>To detect and prevent fraudulent activity</li>
                  <li>To improve our platform and user experience</li>
                  <li>To communicate with you about platform updates</li>
                </ul>
              </section>

              <section>
                <h2 className="font-display font-bold text-2xl mb-4">Information Sharing</h2>
                <p className="text-muted-foreground leading-relaxed mb-4">
                  We share limited information to facilitate food distribution:
                </p>
                <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                  <li>Donors and recipients see volunteer names and phone numbers for coordination</li>
                  <li>Volunteers see donor and recipient contact information for pickups/deliveries</li>
                  <li>Location data is shared during active deliveries for tracking purposes</li>
                  <li>We do not sell or share your personal information with third parties for marketing</li>
                </ul>
              </section>

              <section>
                <h2 className="font-display font-bold text-2xl mb-4">Data Security</h2>
                <p className="text-muted-foreground leading-relaxed">
                  We use Firebase Authentication and Firestore for secure data storage. All data transmission is encrypted using industry-standard SSL/TLS protocols. Passwords are hashed and never stored in plain text. Email OTP verification ensures account authenticity.
                </p>
              </section>

              <section>
                <h2 className="font-display font-bold text-2xl mb-4">Your Rights</h2>
                <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                  <li>Access your personal data</li>
                  <li>Correct inaccurate information</li>
                  <li>Request deletion of your account and data</li>
                  <li>Opt-out of non-essential communications</li>
                  <li>Withdraw consent for data processing</li>
                </ul>
              </section>

              <section>
                <h2 className="font-display font-bold text-2xl mb-4">Contact Us</h2>
                <p className="text-muted-foreground leading-relaxed">
                  If you have questions about this Privacy Policy, please contact us at privacy@foodconnect.com
                </p>
              </section>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
