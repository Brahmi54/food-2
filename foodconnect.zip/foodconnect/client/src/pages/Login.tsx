import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Heart } from "lucide-react";
import { signInWithEmail, sendPasswordReset } from "@/lib/auth";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";

export default function Login() {
  const { toast } = useToast();
  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [forgotPasswordEmail, setForgotPasswordEmail] = useState("");
  const [isForgotPasswordOpen, setIsForgotPasswordOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  // Redirect to appropriate dashboard if already logged in
  useEffect(() => {
    if (!authLoading && isAuthenticated && user) {
      const redirectMap: Record<string, string> = {
        donor: "/dashboard/donor",
        recipient: "/dashboard/recipient",
        volunteer: "/dashboard/volunteer",
        admin: "/dashboard/admin",
      };
      setLocation(redirectMap[user.role] || "/");
    }
  }, [isAuthenticated, user, authLoading, setLocation]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      await signInWithEmail(email, password);
      toast({
        title: "Welcome back!",
        description: "You have successfully logged in",
      });
      // Redirect will happen automatically via useEffect
    } catch (error: any) {
      let errorMessage = "Invalid email or password";
      
      if (error.message?.includes("auth/invalid-credential") || error.message?.includes("invalid-credential")) {
        errorMessage = "The email or password you entered is incorrect. Please check your credentials or reset your password.";
      } else if (error.message?.includes("auth/user-not-found")) {
        errorMessage = "No account found with this email. Please register first.";
      } else if (error.message?.includes("auth/wrong-password")) {
        errorMessage = "Incorrect password. Try 'Forgot Password?' to reset it.";
      } else if (error.message?.includes("auth/too-many-requests")) {
        errorMessage = "Too many failed login attempts. Please try again later or reset your password.";
      }
      
      toast({
        title: "Login Failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async () => {
    if (!forgotPasswordEmail) {
      toast({
        title: "Email Required",
        description: "Please enter your email address",
        variant: "destructive",
      });
      return;
    }

    try {
      await sendPasswordReset(forgotPasswordEmail);
      toast({
        title: "Password Reset Email Sent",
        description: "Check your inbox for the password reset link",
      });
      setIsForgotPasswordOpen(false);
      setForgotPasswordEmail("");
    } catch (error: any) {
      toast({
        title: "Failed to Send",
        description: error.message || "Please try again",
        variant: "destructive",
      });
    }
  };

  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-4">
            <div className="relative">
              <Heart className="h-8 w-8 text-primary fill-primary" />
              <div className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-secondary rounded-full"></div>
            </div>
            <span className="font-display font-bold text-2xl">Food<span className="text-primary">Connect</span></span>
          </Link>
          <h1 className="font-display font-bold text-3xl mb-2">Welcome Back</h1>
          <p className="text-muted-foreground">Sign in to your account to continue</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Login</CardTitle>
            <CardDescription>Enter your credentials to access your dashboard</CardDescription>
          </CardHeader>
          <form onSubmit={handleLogin}>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  data-testid="input-email"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  data-testid="input-password"
                />
              </div>
              <div className="flex justify-end">
                <Dialog open={isForgotPasswordOpen} onOpenChange={setIsForgotPasswordOpen}>
                  <DialogTrigger asChild>
                    <Button variant="ghost" size="sm" className="px-0 h-auto text-sm text-primary hover:text-primary hover:underline" data-testid="button-forgot-password-trigger">
                      Forgot Password?
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Reset Password</DialogTitle>
                      <DialogDescription>
                        Enter your email address and we'll send you a link to reset your password.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="py-4">
                      <Label htmlFor="forgot-email">Email</Label>
                      <Input
                        id="forgot-email"
                        type="email"
                        placeholder="you@example.com"
                        value={forgotPasswordEmail}
                        onChange={(e) => setForgotPasswordEmail(e.target.value)}
                        className="mt-2"
                        data-testid="input-forgot-password-email"
                      />
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsForgotPasswordOpen(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleForgotPassword} data-testid="button-send-reset-link">
                        Send Reset Link
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col gap-4">
              <Button 
                type="submit" 
                className="w-full" 
                disabled={loading}
                data-testid="button-login"
              >
                {loading ? "Signing In..." : "Sign In"}
              </Button>
              <p className="text-sm text-center text-muted-foreground">
                Don't have an account?{" "}
                <Link href="/register">
                  <span className="text-primary hover:underline cursor-pointer font-medium">Sign up</span>
                </Link>
              </p>
            </CardFooter>
          </form>
        </Card>
      </div>
    </div>
  );
}
