import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import StatCard from "@/components/StatCard";
import DonationCard from "@/components/DonationCard";
import NearbyVolunteersMap from "@/components/NearbyVolunteersMap";
import { Heart, Package, CheckCircle, TrendingUp, Plus, LogOut, AlertCircle, User as UserIcon } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useAuth } from "@/contexts/AuthContext";
import { signOut } from "@/lib/auth";
import { createDonation, subscribeToDonations, getOrCreateDonorStats, updateDonorStats } from "@/lib/firestore";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import type { Donation, InsertDonation, DonorStats } from "@shared/schema";

export default function DonorDashboard() {
  const { user, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [donations, setDonations] = useState<Donation[]>([]);
  const [stats, setStats] = useState<DonorStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const [formData, setFormData] = useState({
    foodType: "",
    quantity: "",
    location: "",
    address: "",
    expiresIn: "",
    description: ""
  });

  // Subscribe to donations in real-time
  useEffect(() => {
    if (!user) return;

    setError(null);
    const loadingTimeout = setTimeout(() => setLoading(false), 5000);

    const unsubscribe = subscribeToDonations(
      { donorId: user.id },
      (updatedDonations) => {
        setDonations(updatedDonations);
        setLoading(false);
        clearTimeout(loadingTimeout);
        
        // Calculate stats from donations
        calculateStats(updatedDonations);
      },
      (error) => {
        console.error("Error loading donations:", error);
        setError("Unable to load donations. Please check Firebase Console for missing indexes.");
        setLoading(false);
        clearTimeout(loadingTimeout);
      }
    );

    return () => {
      clearTimeout(loadingTimeout);
      unsubscribe();
    };
  }, [user]);

  // Load donor stats
  useEffect(() => {
    if (!user) return;

    const loadStats = async () => {
      try {
        const donorStats = await getOrCreateDonorStats(user.id);
        setStats(donorStats);
      } catch (error) {
        console.error("Error loading stats:", error);
      }
    };

    loadStats();
  }, [user]);

  const calculateStats = async (donationsList: Donation[]) => {
  if (!user) return;

  // Calculate donation statistics
  const totalDonations = donationsList.length;
  const activeListings = donationsList.filter(
    (d) => d.status === "available" || d.status === "pending"
  ).length;
  const completedDonations = donationsList.filter(
    (d) => d.status === "completed"
  ).length;

  // Impact calculation (example formula)
  const impactScore = totalDonations * 10 + completedDonations * 50;

  try {
    // ✅ Ensure Firestore donor stats document always exists and updates
    const updatedStats: DonorStats = {
      donorId: user.id,
      totalDonations,
      activeListings,
      completedDonations,
      impactScore,
      lastUpdated: new Date(),
    };

    await updateDonorStats(user.id, updatedStats);

    // ✅ Instant UI sync
    setStats((prev) => ({
      ...(prev || {}), // prevent null overwrites
      ...updatedStats,
    }));
  } catch (error) {
    console.error("Error updating donor stats:", error);
  }
};
  const handleCreateDonation = async () => {
    if (!user) return;

    // Validate form
    if (!formData.foodType || !formData.quantity || !formData.location || !formData.address || !formData.expiresIn) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    setSubmitting(true);

    try {
      // Calculate expiry timestamp from selected hours
      const hoursMatch = formData.expiresIn.match(/(\d+)/);
      const hours = hoursMatch ? parseInt(hoursMatch[1]) : 2;
      const expiresAt = new Date();
      expiresAt.setHours(expiresAt.getHours() + hours);

      const donationData: InsertDonation = {
  donorId: user.id,
  donorName: user.name,
  donorPhone: user.phone,
  foodType: formData.foodType,
  quantity: formData.quantity,
  description: formData.description?.trim() || "", // ✅ safe fallback
  location: formData.location,
  address: formData.address,
  expiresAt,
};

      await createDonation(donationData);

      toast({
        title: "Success",
        description: "Donation created successfully!",
      });

      setIsCreateOpen(false);
      setFormData({ 
        foodType: "", 
        quantity: "", 
        location: "", 
        address: "",
        expiresIn: "", 
        description: "" 
      });
    } catch (error: any) {
      console.error("Error creating donation:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to create donation",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut();
      setLocation("/login");
    } catch (error: any) {
      console.error("Error logging out:", error);
      toast({
        title: "Error",
        description: "Failed to logout",
        variant: "destructive",
      });
    }
  };

  // Show loading state
  if (authLoading || !user) {
    return (
      <div className="min-h-screen bg-muted/30">
        <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="container flex h-16 items-center justify-between px-4 mx-auto max-w-7xl">
            <div className="flex items-center gap-2">
              <div className="relative">
                <Heart className="h-6 w-6 text-primary fill-primary" />
                <div className="absolute -top-1 -right-1 w-2 h-2 bg-secondary rounded-full"></div>
              </div>
              <span className="font-display font-bold text-xl">Food<span className="text-primary">Connect</span></span>
              <span className="text-sm text-muted-foreground ml-2">/ Donor Dashboard</span>
            </div>
          </div>
        </header>
        <main className="container mx-auto max-w-7xl px-4 py-8">
          <div className="space-y-8">
            <Skeleton className="h-12 w-64" />
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[1, 2, 3, 4].map((i) => (
                <Skeleton key={i} className="h-32" />
              ))}
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted/30">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between px-4 mx-auto max-w-7xl">
          <div className="flex items-center gap-2">
            <div className="relative">
              <Heart className="h-6 w-6 text-primary fill-primary" />
              <div className="absolute -top-1 -right-1 w-2 h-2 bg-secondary rounded-full"></div>
            </div>
            <span className="font-display font-bold text-xl">Food<span className="text-primary">Connect</span></span>
            <span className="text-sm text-muted-foreground ml-2">/ Donor Dashboard</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground" data-testid="text-welcome">Welcome, {user.name}</span>
            <Button variant="ghost" size="sm" onClick={() => setLocation("/profile")} data-testid="button-profile">
              <UserIcon className="h-4 w-4 mr-2" />
              Profile
            </Button>
            <Button variant="ghost" size="sm" onClick={handleLogout} data-testid="button-logout">
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto max-w-7xl px-4 py-8">
        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Database Configuration Required</AlertTitle>
            <AlertDescription>
              {error} The dashboard will still work, but some data may not load. Check the browser console for index creation links.
            </AlertDescription>
          </Alert>
        )}

        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-display font-bold text-3xl mb-2">Donor Dashboard</h1>
            <p className="text-muted-foreground">Manage your food donations and track their impact</p>
          </div>
          
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button size="lg" data-testid="button-create-donation">
                <Plus className="mr-2 h-5 w-5" />
                Create Donation
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Create New Donation</DialogTitle>
                <DialogDescription>Fill in the details of your food donation</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="foodType">Food Type *</Label>
                  <Input
                    id="foodType"
                    placeholder="e.g., Fresh Vegetable Meals"
                    value={formData.foodType}
                    onChange={(e) => setFormData({...formData, foodType: e.target.value})}
                    data-testid="input-food-type"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="quantity">Quantity *</Label>
                  <Input
                    id="quantity"
                    placeholder="e.g., 50 servings"
                    value={formData.quantity}
                    onChange={(e) => setFormData({...formData, quantity: e.target.value})}
                    data-testid="input-quantity"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="location">Pickup Location Name *</Label>
                  <Input
                    id="location"
                    placeholder="e.g., Downtown Restaurant"
                    value={formData.location}
                    onChange={(e) => setFormData({...formData, location: e.target.value})}
                    data-testid="input-location"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="address">Pickup Address *</Label>
                  <Input
                    id="address"
                    placeholder="e.g., 123 Main St, Mumbai, Maharashtra"
                    value={formData.address}
                    onChange={(e) => setFormData({...formData, address: e.target.value})}
                    data-testid="input-address"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="expiresIn">Expires In *</Label>
                  <Select value={formData.expiresIn} onValueChange={(value) => setFormData({...formData, expiresIn: value})}>
                    <SelectTrigger data-testid="select-expires-in">
                      <SelectValue placeholder="Select timeframe" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2 hours">2 hours</SelectItem>
                      <SelectItem value="4 hours">4 hours</SelectItem>
                      <SelectItem value="6 hours">6 hours</SelectItem>
                      <SelectItem value="12 hours">12 hours</SelectItem>
                      <SelectItem value="24 hours">24 hours</SelectItem>
                      <SelectItem value="30 hours">30 hours</SelectItem>
                      <SelectItem value="36 hours">36 hours</SelectItem>
                      <SelectItem value="42 hours">42 hours</SelectItem>
                      <SelectItem value="48 hours">48 hours</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description (Optional)</Label>
                  <Textarea
                    id="description"
                    placeholder="Additional details about the food..."
                    value={formData.description}
                    onChange={(e) => setFormData({...formData, description: e.target.value})}
                    data-testid="input-description"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsCreateOpen(false)} disabled={submitting}>Cancel</Button>
                <Button onClick={handleCreateDonation} disabled={submitting} data-testid="button-submit-donation">
                  {submitting ? "Creating..." : "Create Donation"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {loading ? (
            <>
              {[1, 2, 3, 4].map((i) => (
                <Skeleton key={i} className="h-32" />
              ))}
            </>
          ) : (
            <>
              <StatCard 
                icon={Heart} 
                value={stats?.totalDonations?.toString() || "0"} 
                label="Total Donations" 
                trend={stats && stats.totalDonations > 0 ? `+${Math.min(stats.totalDonations, 3)} this week` : undefined}
                color="text-primary" 
              />
              <StatCard 
                icon={Package} 
                value={stats?.activeListings?.toString() || "0"} 
                label="Active Listings" 
                color="text-secondary" 
              />
              <StatCard 
                icon={CheckCircle} 
                value={stats?.completedDonations?.toString() || "0"} 
                label="Completed" 
                color="text-accent" 
              />
              <StatCard 
                icon={TrendingUp} 
                value={stats?.impactScore?.toString() || "0"} 
                label="Impact Score" 
                trend={stats && stats.impactScore > 0 ? `+${Math.min(stats.impactScore, 120)}` : undefined}
                color="text-primary" 
              />
            </>
          )}
        </div>

        <Card>
          <CardHeader>
            <CardTitle>My Donations</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-64" />
                ))}
              </div>
            ) : donations.length === 0 ? (
              <div className="text-center py-12">
                <Package className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground mb-4">No donations yet</p>
                <Button onClick={() => setIsCreateOpen(true)} data-testid="button-create-first-donation">
                  <Plus className="mr-2 h-4 w-4" />
                  Create Your First Donation
                </Button>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {donations.map((donation) => {
                  // Calculate time remaining
                  const now = new Date();
                  const expiresAt = new Date(donation.expiresAt);
                  const diffMs = expiresAt.getTime() - now.getTime();
                  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
                  const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
                  
                  let expiresIn: string;
                  if (diffMs < 0) {
                    expiresIn = "Expired";
                  } else if (diffHours > 0) {
                    expiresIn = `${diffHours} hour${diffHours > 1 ? 's' : ''}`;
                  } else {
                    expiresIn = `${diffMins} min${diffMins !== 1 ? 's' : ''}`;
                  }

                  return (
                    <DonationCard
  key={donation.id}
  id={donation.id}
  foodType={donation.foodType}
  quantity={donation.quantity}
  location={`${donation.location}, ${donation.address}`}
  expiresIn={expiresIn}
  status={donation.status}
  donorName={donation.donorName}
  recipientName={donation.recipientName}
  recipientPhone={donation.recipientPhone}
  volunteerName={donation.deliveryName}
  volunteerPhone={donation.deliveryPhone}
/>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Nearby Volunteers Map */}
        <div className="mt-8">
          <NearbyVolunteersMap />
        </div>
      </main>
    </div>
  );
}
