import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const faqs = [
  {
    question: "How does FoodConnect work?",
    answer: "FoodConnect connects food donors (restaurants, hotels, households) with recipients (NGOs, shelters, individuals) through verified volunteers. Donors post surplus food details, recipients request donations, and volunteers coordinate pickup and delivery with real-time tracking."
  },
  {
    question: "How do I register on FoodConnect?",
    answer: "Click 'Get Started', choose your role (Donor, Volunteer, or Recipient), fill in your details including email and phone number, and verify your email verfication. Once verified, you can access your dashboard."
  },
  {
    question: "Is FoodConnect free to use?",
    answer: "Yes, FoodConnect is completely free for all users. Our mission is to reduce food waste and feed communities without any cost barriers."
  },
  {
    question: "How is my data kept secure?",
    answer: "We use Firebase Authentication with email OTP verification. All data is encrypted and stored securely in Firebase Firestore. Only verified users can access the platform, and admins monitor for fraudulent activity."
  },
  {
    question: "Can I track food deliveries in real-time?",
    answer: "Yes! Once a volunteer accepts a delivery, donors and recipients can track the volunteer's live location using Google Maps integration, along with estimated arrival time and delivery status."
  },
  {
    question: "What types of food can be donated?",
    answer: "You can donate any surplus food including cooked meals, packaged items, fresh produce, bakery products, and more. Just ensure the food is safe for consumption and specify expiry details when creating a donation."
  },
  {
    question: "How are volunteers verified?",
    answer: "All volunteers must complete email verification and register a phone number. The admin dashboard monitors volunteer activity and can flag or remove suspicious accounts to maintain platform trust."
  },
  {
    question: "What if I need to cancel a donation?",
    answer: "You can manage your donations from your dashboard. If a request hasn't been accepted yet, you can cancel or edit the donation details. If a volunteer has already accepted, please contact them directly using the provided phone number."
  },
  {
    question: "How quickly should food be picked up?",
    answer: "We recommend coordinating pickup within the expiry timeframe specified by the donor. Volunteers can see expiry times and prioritize urgent pickups to ensure food reaches recipients while fresh."
  },
  {
    question: "Can organizations register as donors or recipients?",
    answer: "Yes! Restaurants, hotels, NGOs, shelters, and other organizations can register using their organizational email and details. We welcome both individual and organizational participation."
  }
];

export default function FAQ() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <section className="py-16 md:py-20 lg:py-24">
          <div className="container mx-auto max-w-4xl px-4">
            <div className="text-center mb-12 md:mb-16">
              <h1 className="font-display font-bold text-4xl md:text-5xl mb-6">Frequently Asked Questions</h1>
              <p className="text-xl text-muted-foreground leading-relaxed">
                Find answers to common questions about FoodConnect
              </p>
            </div>

            <Accordion type="single" collapsible className="space-y-4">
              {faqs.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`} className="border rounded-lg px-6">
                  <AccordionTrigger className="text-left font-semibold hover:no-underline">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>

            <div className="mt-12 p-6 rounded-lg border bg-card text-center">
              <h3 className="font-display font-semibold text-xl mb-2">Still have questions?</h3>
              <p className="text-muted-foreground mb-4">
                Contact our support team and we'll be happy to help
              </p>
              <a href="/contact" className="text-primary hover:underline font-medium">
                Contact Us
              </a>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
