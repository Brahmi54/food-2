import { useState, useRef, type ChangeEvent } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { Heart, User as UserIcon, Mail, Phone, MapPin, Edit, Save, X, Upload, Loader2 } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { updateUser } from "@/lib/firestore";
import { uploadProfileImage } from "@/lib/storage";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

export default function Profile() {
  const { user, loading: authLoading, refreshUser } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [formData, setFormData] = useState({
    name: user?.name || "",
    phone: user?.phone || "",
    address: user?.address || "",
    organization: user?.organization || "",
  });

  const [tempImageUrl, setTempImageUrl] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);

  const handleEdit = () => {
    if (user) {
      setFormData({
        name: user.name,
        phone: user.phone,
        address: user.address || "",
        organization: user.organization || "",
      });
    }
    setIsEditing(true);
  };

  const handleCancel = () => {
    setIsEditing(false);
    setTempImageUrl(null);
    setImageFile(null);
  };

  const handleImageSelect = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type
      if (!file.type.startsWith("image/")) {
        toast({
          title: "Invalid File",
          description: "Please select an image file",
          variant: "destructive",
        });
        return;
      }

      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "File Too Large",
          description: "Please select an image smaller than 5MB",
          variant: "destructive",
        });
        return;
      }

      setImageFile(file);
      setTempImageUrl(URL.createObjectURL(file));
    }
  };

  const handleSave = async () => {
    if (!user) return;

    try {
      setSaving(true);

      let profileImageUrl = user.profileImage;

      // Upload new profile image if selected
      if (imageFile) {
        setUploading(true);
        profileImageUrl = await uploadProfileImage(user.id, imageFile);
        setUploading(false);
      }

      // Update user profile in Firestore
      await updateUser(user.id, {
        name: formData.name,
        phone: formData.phone,
        address: formData.address || undefined,
        organization: formData.organization || undefined,
        profileImage: profileImageUrl || undefined,
      });

      // Refresh user data
      await refreshUser();

      toast({
        title: "Profile Updated! 🎉",
        description: "Your profile has been successfully updated.",
      });

      setIsEditing(false);
      setTempImageUrl(null);
      setImageFile(null);
    } catch (error) {
      console.error("Error updating profile:", error);
      toast({
        title: "Update Failed",
        description: "Failed to update profile. Please try again.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
      setUploading(false);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-muted/30">
        <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="container flex h-16 items-center justify-between px-4 mx-auto max-w-7xl">
            <div className="flex items-center gap-2">
              <div className="relative">
                <Heart className="h-6 w-6 text-primary fill-primary" />
                <div className="absolute -top-1 -right-1 w-2 h-2 bg-secondary rounded-full"></div>
              </div>
              <span className="font-display font-bold text-xl">Food<span className="text-primary">Connect</span></span>
              <span className="text-sm text-muted-foreground ml-2">/ Profile</span>
            </div>
          </div>
        </header>
        <main className="container mx-auto max-w-3xl px-4 py-8">
          <div className="space-y-6">
            <Skeleton className="h-12 w-48" />
            <Skeleton className="h-96 w-full" />
          </div>
        </main>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-muted/30 flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Not Authenticated</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-4">Please log in to view your profile.</p>
            <Button onClick={() => setLocation("/login")} className="w-full" data-testid="button-login">
              Go to Login
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const displayImage = tempImageUrl || user.profileImage;
  const initials = user.name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);

  return (
    <div className="min-h-screen bg-muted/30">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between px-4 mx-auto max-w-7xl">
          <div className="flex items-center gap-2">
            <div className="relative">
              <Heart className="h-6 w-6 text-primary fill-primary" />
              <div className="absolute -top-1 -right-1 w-2 h-2 bg-secondary rounded-full"></div>
            </div>
            <span className="font-display font-bold text-xl">Food<span className="text-primary">Connect</span></span>
            <span className="text-sm text-muted-foreground ml-2">/ Profile</span>
          </div>
          <Button
            variant="ghost"
            onClick={() => {
              const roleRoutes = {
                donor: "/dashboard/donor",
                recipient: "/dashboard/recipient",
                volunteer: "/dashboard/volunteer",
                admin: "/dashboard/admin",
              };
              setLocation(roleRoutes[user.role] || "/");
            }}
            data-testid="button-back-to-dashboard"
          >
            Back to Dashboard
          </Button>
        </div>
      </header>

      <main className="container mx-auto max-w-3xl px-4 py-8">
        <div className="mb-8">
          <h1 className="font-display font-bold text-3xl mb-2">My Profile</h1>
          <p className="text-muted-foreground">Manage your personal information</p>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Profile Information</CardTitle>
                <CardDescription>Update your profile details and profile picture</CardDescription>
              </div>
              {!isEditing && (
                <Button onClick={handleEdit} data-testid="button-edit-profile">
                  <Edit className="h-4 w-4 mr-2" />
                  Edit Profile
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Profile Image */}
            <div className="flex flex-col items-center gap-4">
              <Avatar className="h-24 w-24">
                <AvatarImage src={displayImage} alt={user.name} />
                <AvatarFallback className="text-2xl">{initials}</AvatarFallback>
              </Avatar>
              {isEditing && (
                <div className="flex flex-col items-center gap-2">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleImageSelect}
                    className="hidden"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploading}
                    data-testid="button-upload-image"
                  >
                    {uploading ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Uploading...
                      </>
                    ) : (
                      <>
                        <Upload className="h-4 w-4 mr-2" />
                        Upload Photo
                      </>
                    )}
                  </Button>
                  {imageFile && (
                    <p className="text-sm text-muted-foreground">{imageFile.name}</p>
                  )}
                </div>
              )}
            </div>

            {/* Profile Fields */}
            <div className="grid gap-6">
              <div className="grid gap-2">
                <Label htmlFor="name">Full Name *</Label>
                {isEditing ? (
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Enter your full name"
                    data-testid="input-name"
                  />
                ) : (
                  <div className="flex items-center gap-2 text-base" data-testid="text-name">
                    <UserIcon className="h-4 w-4 text-muted-foreground" />
                    {user.name}
                  </div>
                )}
              </div>

              <div className="grid gap-2">
                <Label htmlFor="email">Email Address</Label>
                <div className="flex items-center gap-2 text-base text-muted-foreground" data-testid="text-email">
                  <Mail className="h-4 w-4" />
                  {user.email} <span className="text-xs">(Read-only)</span>
                </div>
              </div>

              <div className="grid gap-2">
                <Label htmlFor="role">Role</Label>
                <div className="flex items-center gap-2 text-base text-muted-foreground capitalize" data-testid="text-role">
                  <UserIcon className="h-4 w-4" />
                  {user.role} <span className="text-xs">(Read-only)</span>
                </div>
              </div>

              <div className="grid gap-2">
                <Label htmlFor="phone">Phone Number *</Label>
                {isEditing ? (
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="Enter your phone number"
                    data-testid="input-phone"
                  />
                ) : (
                  <div className="flex items-center gap-2 text-base" data-testid="text-phone">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    {user.phone}
                  </div>
                )}
              </div>

              <div className="grid gap-2">
                <Label htmlFor="address">Address</Label>
                {isEditing ? (
                  <Textarea
                    id="address"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    placeholder="Enter your address"
                    rows={3}
                    data-testid="input-address"
                  />
                ) : (
                  <div className="flex items-start gap-2 text-base" data-testid="text-address">
                    <MapPin className="h-4 w-4 text-muted-foreground mt-1" />
                    {user.address || <span className="text-muted-foreground">Not provided</span>}
                  </div>
                )}
              </div>

              {(user.role === "donor" || isEditing) && (
                <div className="grid gap-2">
                  <Label htmlFor="organization">Organization</Label>
                  {isEditing ? (
                    <Input
                      id="organization"
                      value={formData.organization}
                      onChange={(e) => setFormData({ ...formData, organization: e.target.value })}
                      placeholder="Enter your organization name (optional)"
                      data-testid="input-organization"
                    />
                  ) : (
                    <div className="flex items-center gap-2 text-base" data-testid="text-organization">
                      {user.organization || <span className="text-muted-foreground">Not provided</span>}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Action Buttons */}
            {isEditing && (
              <div className="flex gap-3 pt-4">
                <Button
                  onClick={handleSave}
                  disabled={saving || !formData.name || !formData.phone}
                  className="flex-1"
                  data-testid="button-save-profile"
                >
                  {saving ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="h-4 w-4 mr-2" />
                      Save Changes
                    </>
                  )}
                </Button>
                <Button
                  variant="outline"
                  onClick={handleCancel}
                  disabled={saving}
                  data-testid="button-cancel-edit"
                >
                  <X className="h-4 w-4 mr-2" />
                  Cancel
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
