import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import StatCard from "@/components/StatCard";
import DeliveryMap from "@/components/DeliveryMap";
import VolunteerLocationTracker from "@/components/VolunteerLocationTracker";
import {
  Heart,
  Truck,
  CheckCircle,
  TrendingUp,
  LogOut,
  MapPin,
  Phone,
  AlertCircle,
  User as UserIcon,
} from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useAuth } from "@/contexts/AuthContext";
import { signOut } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import {
  subscribeToDeliveries,
  updateDeliveryRequest,
  getDonation,
  updateDonation,
  getOrCreateVolunteerStats,
  updateVolunteerStats,
} from "@/lib/firestore";
import type { DeliveryRequest, Donation, VolunteerStats } from "@shared/schema";
import { doc, onSnapshot } from "firebase/firestore";
import { db } from "@/lib/firebase";

export default function VolunteerDashboard() {
  const { user, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const [activeDelivery, setActiveDelivery] = useState<DeliveryRequest | null>(null);
  const [activeDonation, setActiveDonation] = useState<Donation | null>(null);
  const [pendingDeliveries, setPendingDeliveries] = useState<DeliveryRequest[]>([]);
  const [stats, setStats] = useState<VolunteerStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [acceptingId, setAcceptingId] = useState<string | null>(null);
  const [startingDelivery, setStartingDelivery] = useState(false);
  const [completingDelivery, setCompletingDelivery] = useState(false);
  const [mapDistance, setMapDistance] = useState<string>("");
  const [mapDuration, setMapDuration] = useState<string>("");
  const [error, setError] = useState<string | null>(null);

  // ----------------------
  // Real-time volunteer stats subscription
  // ----------------------
  useEffect(() => {
    if (!user?.id) return;

    const statsRef = doc(db, "volunteerStats", user.id);
    const unsub = onSnapshot(
      statsRef,
      (snap) => {
        if (snap.exists()) {
          // snap.data() may not be typed; cast carefully
          setStats(snap.data() as VolunteerStats);
        }
      },
      (err) => {
        console.error("Volunteer stats onSnapshot error:", err);
      }
    );

    return () => unsub();
  }, [user?.id]);

  // ----------------------
  // Subscriptions: active + pending deliveries for volunteers
  // ----------------------
  useEffect(() => {
    if (!user || user.role !== "volunteer") return;

    setLoading(true);
    setError(null);
    const loadingTimeout = setTimeout(() => setLoading(false), 5000);

    const unsubscribeActive = subscribeToDeliveries(
      { volunteerId: user.id, status: "in_progress" },
      (deliveries) => {
        setActiveDelivery(deliveries.length > 0 ? deliveries[0] : null);
        clearTimeout(loadingTimeout);
        setLoading(false);
      },
      (err) => {
        console.error("Error loading active deliveries:", err);
        setError("Unable to load active deliveries. Check console for Firestore index hints.");
        clearTimeout(loadingTimeout);
        setLoading(false);
      }
    );

    const unsubscribePending = subscribeToDeliveries(
      { status: "pending" },
      (deliveries) => {
        setPendingDeliveries(deliveries);
        clearTimeout(loadingTimeout);
        setLoading(false);
      },
      (err) => {
        console.error("Error loading pending deliveries:", err);
        setError("Unable to load pending deliveries. Check console for Firestore index hints.");
        clearTimeout(loadingTimeout);
        setLoading(false);
      }
    );

    // ensure volunteer stats doc exists locally (will also be synced via onSnapshot)
    const loadStats = async () => {
      try {
        const volunteerStats = await getOrCreateVolunteerStats(user.id);
        setStats(volunteerStats);
      } catch (err) {
        console.error("Error ensuring volunteer stats:", err);
      }
    };
    loadStats();

    return () => {
      clearTimeout(loadingTimeout);
      try {
        unsubscribeActive();
      } catch {}
      try {
        unsubscribePending();
      } catch {}
    };
  }, [user]);

  // ----------------------
  // Load donation record for active delivery (so UI can show donation details)
  // ----------------------
  useEffect(() => {
    const fetchActiveDonation = async () => {
      if (!activeDelivery?.donationId) {
        setActiveDonation(null);
        return;
      }
      try {
        const donation = await getDonation(activeDelivery.donationId);
        setActiveDonation(donation);
      } catch (err) {
        console.error("Error fetching active donation:", err);
        setActiveDonation(null);
      }
    };
    fetchActiveDonation();
  }, [activeDelivery]);

  // ----------------------
  // Accept delivery (volunteer action)
  // - updates deliveryRequest (status + volunteer info)
  // - updates donation (assign volunteer)
  // - increments volunteerStats.activeDeliveries
  // ----------------------
  const handleAcceptDelivery = async (delivery: DeliveryRequest) => {
    if (!user) return;
    if (!delivery?.id) return;

    setAcceptingId(delivery.id);
    try {
      // 1) Update deliveryRequest doc
      await updateDeliveryRequest(delivery.id, {
        status: "accepted",
        volunteerId: user.id,
        volunteerName: user.name,
        volunteerPhone: user.phone,
        acceptedAt: new Date(),
      });

      // 2) Update donation doc (link volunteer)
      if (delivery.donationId) {
        await updateDonation(delivery.donationId, {
          status: "assigned",
          volunteerId: user.id,
          volunteerName: user.name,
          volunteerPhone: user.phone,
        });
      }

      // 3) Update volunteer stats (create if missing then increment)
      try {
        const vs = await getOrCreateVolunteerStats(user.id);
        await updateVolunteerStats(user.id, {
          activeDeliveries: (vs.activeDeliveries || 0) + 1,
          lastUpdated: new Date(),
        });
      } catch (err) {
        console.error("Error updating volunteer stats after accept:", err);
      }

      toast({
        title: "Delivery Accepted",
        description: "You accepted the delivery — start when ready.",
      });
    } catch (err: any) {
      console.error("Error accepting delivery:", err);
      toast({
        title: "Error",
        description: err?.message || "Failed to accept delivery",
        variant: "destructive",
      });
    } finally {
      setAcceptingId(null);
    }
  };

  // ----------------------
  // Start delivery: mark in_progress (optional separate action)
  // ----------------------
  const handleStartDelivery = async () => {
    if (!user) return;

    const deliveryToStart =
      activeDelivery || pendingDeliveries.find((d) => d.volunteerId === user.id && d.status === "accepted");
    if (!deliveryToStart) {
      toast({ title: "No delivery", description: "No accepted delivery to start." });
      return;
    }

    setStartingDelivery(true);
    try {
      await updateDeliveryRequest(deliveryToStart.id, { status: "in_progress", startedAt: new Date() });

      // note: we already increased activeDeliveries on accept; no double increment here
      toast({ title: "Delivery Started", description: "You're on the way!" });
    } catch (err) {
      console.error("Error starting delivery:", err);
      toast({
        title: "Error",
        description: "Failed to start delivery. Try again.",
        variant: "destructive",
      });
    } finally {
      setStartingDelivery(false);
    }
  };

  // ----------------------
  // Complete delivery: mark completed and update donation & stats
  // ----------------------
  const handleCompleteDelivery = async () => {
    if (!activeDelivery || !user) {
      toast({ title: "No active delivery", description: "No active delivery to complete." });
      return;
    }

    setCompletingDelivery(true);
    try {
      // 1) update delivery request status
      await updateDeliveryRequest(activeDelivery.id, { status: "completed", completedAt: new Date() });

      // 2) update donation status
      if (activeDelivery.donationId) {
        await updateDonation(activeDelivery.donationId, { status: "completed", deliveredAt: new Date() });
      }

      // 3) update volunteer stats: decrement active, increment completed, add meals/distance
      try {
        const currentStats = await getOrCreateVolunteerStats(user.id);
        const estimatedMeals = parseInt(activeDonation?.quantity as any) || 0;
        const estimatedDistance = parseFloat(activeDelivery.distance as any) || 0;

        await updateVolunteerStats(user.id, {
          activeDeliveries: Math.max(0, (currentStats.activeDeliveries || 1) - 1),
          completedDeliveries: (currentStats.completedDeliveries || 0) + 1,
          mealsDelivered: (currentStats.mealsDelivered || 0) + estimatedMeals,
          distanceTraveled: (currentStats.distanceTraveled || 0) + estimatedDistance,
          lastUpdated: new Date(),
        });
      } catch (err) {
        console.error("Error updating volunteer stats after completion:", err);
      }

      toast({ title: "Delivery Completed", description: "Thanks — delivery marked completed." });
    } catch (err) {
      console.error("Error completing delivery:", err);
      toast({
        title: "Error",
        description: "Failed to complete delivery. Try again.",
        variant: "destructive",
      });
    } finally {
      setCompletingDelivery(false);
    }
  };

  // ----------------------
  // Logout
  // ----------------------
  const handleLogout = async () => {
    try {
      await signOut();
      setLocation("/login");
    } catch (err) {
      console.error("Logout error:", err);
      toast({
        title: "Error",
        description: "Failed to logout. Please try again.",
        variant: "destructive",
      });
    }
  };

  // ----------------------
  // Render
  // ----------------------
  if (authLoading) {
    return (
      <div className="min-h-screen bg-muted/30 flex items-center justify-center">
        <div className="text-center">
          <Skeleton className="h-12 w-12 rounded-full mx-auto mb-4" />
          <Skeleton className="h-4 w-32 mx-auto" />
        </div>
      </div>
    );
  }

  if (!user || user.role !== "volunteer") {
    return (
      <div className="min-h-screen bg-muted/30 flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Access Denied</CardTitle>
            <CardDescription>This dashboard is only accessible to volunteers.</CardDescription>
          </CardHeader>
          <CardFooter>
            <Button onClick={() => setLocation("/")} className="w-full">Go to Home</Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted/30">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between px-4 mx-auto max-w-7xl">
          <div className="flex items-center gap-2">
            <div className="relative">
              <Heart className="h-6 w-6 text-primary fill-primary" />
              <div className="absolute -top-1 -right-1 w-2 h-2 bg-secondary rounded-full" />
            </div>
            <span className="font-display font-bold text-xl">Food<span className="text-primary">Connect</span></span>
            <span className="text-sm text-muted-foreground ml-2">/ Volunteer Dashboard</span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">Welcome, {user.name}</span>
            <Button variant="ghost" size="sm" onClick={() => setLocation("/profile")} data-testid="button-profile">
              <UserIcon className="h-4 w-4 mr-2" /> Profile
            </Button>
            <Button variant="ghost" size="sm" onClick={handleLogout} data-testid="button-logout">
              <LogOut className="h-4 w-4 mr-2" /> Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto max-w-7xl px-4 py-8">
        <div className="mb-8">
          <h1 className="font-display font-bold text-3xl mb-2">Volunteer Dashboard</h1>
          <p className="text-muted-foreground">Coordinate food pickups and deliveries</p>
        </div>

        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Database Configuration Required</AlertTitle>
            <AlertDescription>{error} The UI will still work but some data may not load.</AlertDescription>
          </Alert>
        )}

        {loading ? (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[1, 2, 3, 4].map((i) => <Card key={i}><CardHeader className="space-y-2"><Skeleton className="h-4 w-20" /><Skeleton className="h-8 w-16" /></CardHeader></Card>)}
            </div>
            <Skeleton className="h-96 w-full" />
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <StatCard icon={Truck} value={stats?.activeDeliveries?.toString() || "0"} label="Active Delivery" color="text-primary" />
              <StatCard icon={CheckCircle} value={stats?.completedDeliveries?.toString() || "0"} label="Completed" color="text-secondary" />
              <StatCard icon={TrendingUp} value={`${(stats?.distanceTraveled ?? 0).toFixed(1)} km`} label="Distance Traveled" color="text-accent" />
              <StatCard icon={Heart} value={stats?.mealsDelivered?.toString() || "0"} label="Meals Delivered" color="text-primary" />
            </div>

            {activeDelivery && (
              <Card className="shadow-md border rounded-lg mb-6">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">Active Delivery</CardTitle>
                  <CardDescription>Details of your current food delivery</CardDescription>
                </CardHeader>

                <CardContent className="space-y-4">
                  <div className="p-4 rounded-lg border bg-card">
                    <h4 className="font-semibold mb-2 flex items-center gap-2">🟢 Donor Details</h4>
                    <div className="text-sm space-y-1">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Name:</span>
                        <span data-testid="text-donor-name">{activeDelivery.donorName || "N/A"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Phone:</span>
                        <span data-testid="text-donor-phone">{activeDelivery.donorPhone || "N/A"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Address:</span>
                        <span>{activeDelivery.donorAddress || "N/A"}</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 rounded-lg border bg-card">
                    <h4 className="font-semibold mb-2 flex items-center gap-2">🔴 Recipient Details</h4>
                    <div className="text-sm space-y-1">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Name:</span>
                        <span data-testid="text-recipient-name">{activeDelivery.recipientName || "N/A"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Phone:</span>
                        <span data-testid="text-recipient-phone">{activeDelivery.recipientPhone || "N/A"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Address:</span>
                        <span>{activeDelivery.recipientAddress || "N/A"}</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-3 rounded-md bg-muted text-center text-sm font-medium">
                    🚚 Status: <span className="text-primary capitalize">{activeDelivery.status || "pending"}</span>
                  </div>

                  {/* Complete button shown only to assigned volunteer */}
                  {activeDelivery.volunteerId === user.id && activeDelivery.status !== "completed" && (
                    <div className="flex gap-3">
                      <Button onClick={handleStartDelivery} disabled={startingDelivery}>
                        {startingDelivery ? "Starting..." : "Start Delivery"}
                      </Button>
                      <Button onClick={handleCompleteDelivery} disabled={completingDelivery} className="bg-green-600 hover:bg-green-700">
                        {completingDelivery ? "Completing..." : "Mark Delivered"}
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            <Card>
              <CardHeader>
                <CardTitle>Available Deliveries</CardTitle>
                <CardDescription>
                  {pendingDeliveries.length === 0 ? "No deliveries available at the moment" : `${pendingDeliveries.length} delivery${pendingDeliveries.length !== 1 ? "s" : ""} available`}
                </CardDescription>
              </CardHeader>

              <CardContent>
                {pendingDeliveries.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <Truck className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Check back later for new delivery requests</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {pendingDeliveries.map((delivery) => (
                      <div key={delivery.id} className="p-4 rounded-lg border bg-card hover-elevate" data-testid={`card-delivery-${delivery.id}`}>
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <h4 className="font-semibold mb-1" data-testid={`text-delivery-recipient-${delivery.id}`}>{delivery.recipientName}</h4>

                            {delivery.donorName && (
                              <p className="text-sm text-muted-foreground flex items-center gap-1">
                                <UserIcon className="h-4 w-4 text-green-600" />
                                Donor: <span className="font-medium">{delivery.donorName}</span> ({delivery.donorPhone})
                              </p>
                            )}

                            {delivery.recipientName && (
                              <p className="text-sm text-muted-foreground flex items-center gap-1">
                                <UserIcon className="h-4 w-4 text-red-600" />
                                Recipient: <span className="font-medium">{delivery.recipientName}</span> ({delivery.recipientPhone})
                              </p>
                            )}

                            <p className="text-sm text-muted-foreground mb-3">Delivery ID: {delivery.id.slice(0, 8)}</p>

                            <div className="flex items-center gap-4 text-sm mb-2">
                              <div className="flex items-center gap-1">
                                <MapPin className="h-3 w-3 text-muted-foreground" />
                                <span>{delivery.recipientAddress}</span>
                              </div>
                            </div>

                            {delivery.distance && <p className="text-sm text-muted-foreground">Distance: {delivery.distance}</p>}
                            {delivery.notes && <p className="text-sm text-muted-foreground mt-2">Notes: {delivery.notes}</p>}
                          </div>

                          <Button
                            onClick={() => handleAcceptDelivery(delivery)}
                            disabled={acceptingId === delivery.id || !!activeDelivery}
                            data-testid={`button-accept-${delivery.id}`}
                          >
                            {acceptingId === delivery.id ? "Accepting..." : "Accept"}
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Location Tracker */}
            <VolunteerLocationTracker />
          </>
        )}
      </main>
    </div>
  );
}
