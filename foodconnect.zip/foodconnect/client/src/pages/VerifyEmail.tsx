import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Heart, Mail, RefreshCw, CheckCircle, LogOut } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { sendEmailVerification } from "firebase/auth";
import { signOut } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";

export default function VerifyEmail() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const { firebaseUser, isEmailVerified, user, loading, refreshUser } = useAuth();
  const [resending, setResending] = useState(false);
  const [countdown, setCountdown] = useState(0);

  useEffect(() => {
    // Redirect if already verified
    if (!loading && isEmailVerified && user) {
      const dashboardPath = `/dashboard/${user.role}`;
      setLocation(dashboardPath);
    }
  }, [isEmailVerified, user, loading, setLocation]);

  useEffect(() => {
    // Countdown timer for resend button
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  const handleResendVerification = async () => {
    if (!firebaseUser || countdown > 0) return;

    setResending(true);

    try {
      await sendEmailVerification(firebaseUser);
      
      toast({
        title: "Verification Email Resent ✅",
        description: "Check your inbox for the new verification link",
      });

      setCountdown(60); // 60 second cooldown
    } catch (error: any) {
      toast({
        title: "Failed to Resend",
        description: error.message || "Please try again later",
        variant: "destructive",
      });
    } finally {
      setResending(false);
    }
  };

  const handleCheckVerification = async () => {
    if (!firebaseUser) return;

    try {
      // Reload Firebase user to get latest emailVerified status
      await firebaseUser.reload();
      
      // Check if verified
      if (firebaseUser.emailVerified) {
        // Force context to update by calling refreshUser
        // This will update both firebaseUser state and user data
        await refreshUser();
        
        toast({
          title: "Email Verified! 🎉",
          description: "Redirecting to your dashboard...",
        });
        
        // Small delay to allow context to update, then redirect
        setTimeout(() => {
          if (user) {
            const dashboardPath = `/dashboard/${user.role}`;
            setLocation(dashboardPath);
          }
        }, 500);
      } else {
        toast({
          title: "Not Yet Verified",
          description: "Please click the link in your email first",
          variant: "destructive",
        });
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to check verification status",
        variant: "destructive",
      });
    }
  };

  const handleLogout = async () => {
    try {
      await signOut();
      toast({
        title: "Logged Out",
        description: "You have been logged out successfully",
      });
      setLocation("/login");
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to log out",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!firebaseUser) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Please Log In</CardTitle>
            <CardDescription>You need to be logged in to verify your email</CardDescription>
          </CardHeader>
          <CardFooter>
            <Link href="/login" className="w-full">
              <Button className="w-full" data-testid="button-login">Go to Login</Button>
            </Link>
          </CardFooter>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-4">
            <div className="relative">
              <Heart className="h-8 w-8 text-primary fill-primary" />
              <div className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-secondary rounded-full"></div>
            </div>
            <span className="font-display font-bold text-2xl">Food<span className="text-primary">Connect</span></span>
          </Link>
          <h1 className="font-display font-bold text-3xl mb-2">Verify Your Email</h1>
          <p className="text-muted-foreground">We've sent a verification link to your email</p>
        </div>

        <Card>
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
                <Mail className="h-8 w-8 text-primary" />
              </div>
            </div>
            <CardTitle>Check Your Inbox</CardTitle>
            <CardDescription className="text-base">
              We've sent a verification link to <strong>{firebaseUser.email}</strong>
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-4">
            <div className="bg-muted/50 rounded-lg p-4 space-y-2">
              <p className="text-sm font-medium">Follow these steps:</p>
              <ol className="text-sm text-muted-foreground space-y-2 list-decimal list-inside">
                <li>Open your email inbox</li>
                <li>Find the email from FoodConnect</li>
                <li>Click the verification link</li>
                <li>Return here and click "I've Verified My Email"</li>
              </ol>
            </div>

            <Button
              onClick={handleCheckVerification}
              className="w-full"
              size="lg"
              data-testid="button-check-verification"
            >
              <CheckCircle className="mr-2 h-5 w-5" />
              I've Verified My Email
            </Button>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-card px-2 text-muted-foreground">Didn't receive the email?</span>
              </div>
            </div>

            <Button
              onClick={handleResendVerification}
              disabled={resending || countdown > 0}
              variant="outline"
              className="w-full"
              data-testid="button-resend-verification"
            >
              <RefreshCw className={`mr-2 h-4 w-4 ${resending ? 'animate-spin' : ''}`} />
              {countdown > 0 ? `Resend in ${countdown}s` : resending ? 'Sending...' : 'Resend Verification Email'}
            </Button>
          </CardContent>

          <CardFooter className="flex flex-col gap-3 text-center text-sm text-muted-foreground">
            <p>Check your spam folder if you don't see the email</p>
            <Button
              onClick={handleLogout}
              variant="ghost"
              size="sm"
              className="text-primary hover:text-primary hover:underline"
              data-testid="button-logout"
            >
              <LogOut className="mr-2 h-4 w-4" />
              Sign Out & Return to Login
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}
