import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function Terms() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <section className="py-16 md:py-20 lg:py-24">
          <div className="container mx-auto max-w-4xl px-4">
            <div className="mb-12">
              <h1 className="font-display font-bold text-4xl md:text-5xl mb-4">Terms of Service</h1>
              <p className="text-muted-foreground">Last updated: {new Date().toLocaleDateString()}</p>
            </div>

            <div className="prose prose-gray dark:prose-invert max-w-none space-y-8">
              <section>
                <h2 className="font-display font-bold text-2xl mb-4">Acceptance of Terms</h2>
                <p className="text-muted-foreground leading-relaxed">
                  By accessing and using FoodConnect, you accept and agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our platform.
                </p>
              </section>

              <section>
                <h2 className="font-display font-bold text-2xl mb-4">User Responsibilities</h2>
                <div className="space-y-4">
                  <div>
                    <h3 className="font-semibold text-lg mb-2">For Donors</h3>
                    <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                      <li>Ensure all donated food is safe for consumption</li>
                      <li>Provide accurate information about food type, quantity, and expiry</li>
                      <li>Be available at the specified pickup location during the agreed time</li>
                      <li>Package food appropriately for safe transport</li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-2">For Volunteers</h3>
                    <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                      <li>Handle food safely and maintain hygiene standards</li>
                      <li>Complete deliveries promptly within agreed timeframes</li>
                      <li>Communicate proactively with donors and recipients</li>
                      <li>Enable location tracking during active deliveries</li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-2">For Recipients</h3>
                    <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                      <li>Request only food that you genuinely need</li>
                      <li>Be available to receive deliveries as scheduled</li>
                      <li>Inspect food upon receipt and report any concerns</li>
                      <li>Do not resell donated food</li>
                    </ul>
                  </div>
                </div>
              </section>

              <section>
                <h2 className="font-display font-bold text-2xl mb-4">Account Verification</h2>
                <p className="text-muted-foreground leading-relaxed">
                  All users must complete email OTP verification and provide a valid phone number. FoodConnect reserves the right to verify user identities and suspend accounts that violate our terms or engage in fraudulent activity.
                </p>
              </section>

              <section>
                <h2 className="font-display font-bold text-2xl mb-4">Food Safety Disclaimer</h2>
                <p className="text-muted-foreground leading-relaxed">
                  While FoodConnect facilitates food donation coordination, we are not responsible for food quality, safety, or handling. Donors are responsible for ensuring food safety. Recipients should inspect food before consumption. Volunteers should follow safe food handling practices.
                </p>
              </section>

              <section>
                <h2 className="font-display font-bold text-2xl mb-4">Prohibited Activities</h2>
                <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                  <li>Creating fake accounts or impersonating others</li>
                  <li>Posting false or misleading donation information</li>
                  <li>Reselling donated food for profit</li>
                  <li>Harassing or threatening other users</li>
                  <li>Attempting to breach platform security</li>
                  <li>Using the platform for illegal activities</li>
                </ul>
              </section>

              <section>
                <h2 className="font-display font-bold text-2xl mb-4">Limitation of Liability</h2>
                <p className="text-muted-foreground leading-relaxed">
                  FoodConnect is a coordination platform and is not liable for foodborne illness, injuries, property damage, or any disputes between users. Users interact at their own risk and should exercise caution.
                </p>
              </section>

              <section>
                <h2 className="font-display font-bold text-2xl mb-4">Account Termination</h2>
                <p className="text-muted-foreground leading-relaxed">
                  We reserve the right to suspend or terminate accounts that violate these terms, engage in fraudulent activity, or harm the platform's integrity. Users may also delete their accounts at any time.
                </p>
              </section>

              <section>
                <h2 className="font-display font-bold text-2xl mb-4">Changes to Terms</h2>
                <p className="text-muted-foreground leading-relaxed">
                  FoodConnect may update these Terms of Service. Continued use of the platform after changes constitutes acceptance of new terms. We will notify users of significant changes via email.
                </p>
              </section>

              <section>
                <h2 className="font-display font-bold text-2xl mb-4">Contact</h2>
                <p className="text-muted-foreground leading-relaxed">
                  For questions about these terms, contact us at legal@foodconnect.com
                </p>
              </section>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
