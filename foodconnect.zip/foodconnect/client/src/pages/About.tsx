import Header from "@/components/Header";
import Footer from "@/components/Footer";
import TeamSection from "@/components/TeamSection";
import { Target, Eye, Heart } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <section className="py-16 md:py-20 lg:py-24">
          <div className="container mx-auto max-w-7xl px-4">
            <div className="text-center mb-12 md:mb-16">
              <h1 className="font-display font-bold text-4xl md:text-5xl mb-6">About FoodConnect</h1>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                FoodConnect is a comprehensive platform that bridges the gap between food donors and those in need, 
                promoting sustainability and community welfare through technology.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8 mb-16">
              <div className="text-center p-6">
                <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Target className="h-8 w-8 text-primary" />
                </div>
                <h3 className="font-display font-semibold text-xl mb-2">Our Mission</h3>
                <p className="text-muted-foreground leading-relaxed">
                  To eliminate food waste and alleviate hunger by connecting surplus food with those who need it most.
                </p>
              </div>

              <div className="text-center p-6">
                <div className="w-16 h-16 rounded-2xl bg-secondary/10 flex items-center justify-center mx-auto mb-4">
                  <Eye className="h-8 w-8 text-secondary" />
                </div>
                <h3 className="font-display font-semibold text-xl mb-2">Our Vision</h3>
                <p className="text-muted-foreground leading-relaxed">
                  A world where no food goes to waste and no one goes hungry through efficient community coordination.
                </p>
              </div>

              <div className="text-center p-6">
                <div className="w-16 h-16 rounded-2xl bg-accent/10 flex items-center justify-center mx-auto mb-4">
                  <Heart className="h-8 w-8 text-accent" />
                </div>
                <h3 className="font-display font-semibold text-xl mb-2">Our Values</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Transparency, security, community impact, and sustainable practices guide everything we do.
                </p>
              </div>
            </div>

            <div className="max-w-3xl mx-auto mb-16">
              <h2 className="font-display font-bold text-3xl mb-6 text-center">Our Story</h2>
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <p>
                  Food Connect was born from a simple observation: while millions struggle with food insecurity, restaurants and food businesses discard tons of perfectly good food every day. This paradox inspired our founder, who witnessed first-hand the disconnect between food waste and hunger.
                </p>
                <p>
                  What began as a grassroots initiative connecting a few local restaurants with a nearby shelter has evolved into a comprehensive platform that leverages technology to bridge the gap between food waste and food insecurity at scale.
                </p>
                <p>
                  Our team consists of food industry veterans, technology experts, and social impact leaders who share a common vision: a world where no one goes hungry while good food goes to waste.
                </p>
              </div>
            </div>
          </div>
        </section>

        <TeamSection />
      </main>
      <Footer />
    </div>
  );
}
