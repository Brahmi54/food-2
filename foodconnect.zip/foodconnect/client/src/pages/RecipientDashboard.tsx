import { useState, useEffect, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import StatCard from "@/components/StatCard";
import DonationCard from "@/components/DonationCard";
import NearbyVolunteersMap from "@/components/NearbyVolunteersMap";
import { Heart, Package, CheckCircle, MapPin, LogOut, Search, AlertCircle, User as UserIcon } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { signOut } from "@/lib/auth";
import { 
  subscribeToDonations, 
  subscribeToDeliveries,
  requestDonation
} from "@/lib/firestore";
import type { Donation, DeliveryRequest } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { db } from "@/lib/firebase";
import { doc, updateDoc, getDoc, setDoc, onSnapshot } from "firebase/firestore";
import { Timestamp } from "firebase/firestore"; // ✅ Required for Firestore time values


export default function RecipientDashboard() {
  const [searchQuery, setSearchQuery] = useState("");
  const [availableDonations, setAvailableDonations] = useState<Donation[]>([]);
  const [deliveryRequests, setDeliveryRequests] = useState<DeliveryRequest[]>([]);
  const [loadingDonations, setLoadingDonations] = useState(true);
  const [loadingRequests, setLoadingRequests] = useState(true);
  const [requestingDonation, setRequestingDonation] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { user, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  // Subscribe to available donations
  useEffect(() => {
    setError(null);
    const loadingTimeout = setTimeout(() => setLoadingDonations(false), 5000);

    const unsubscribe = subscribeToDonations(
      { status: "available" }, 
      (donations) => {
        setAvailableDonations(donations);
        setLoadingDonations(false);
        clearTimeout(loadingTimeout);
      },
      (error) => {
        console.error("Error loading donations:", error);
        setError("Unable to load donations. Please check Firebase Console for missing indexes.");
        setLoadingDonations(false);
        clearTimeout(loadingTimeout);
      }
    );

    return () => {
      clearTimeout(loadingTimeout);
      unsubscribe();
    };
  }, []);

  // Subscribe to recipient's delivery requests
  useEffect(() => {
    if (!user?.id) return;

    const loadingTimeout = setTimeout(() => setLoadingRequests(false), 5000);

    const unsubscribe = subscribeToDeliveries(
      { recipientId: user.id }, 
      (requests) => {
        setDeliveryRequests(requests);
        setLoadingRequests(false);
        clearTimeout(loadingTimeout);
      },
      (error) => {
        console.error("Error loading delivery requests:", error);
        setError("Unable to load delivery requests. Please check Firebase Console for missing indexes.");
        setLoadingRequests(false);
        clearTimeout(loadingTimeout);
      }
    );

    return () => {
      clearTimeout(loadingTimeout);
      unsubscribe();
    };
  }, [user?.id]);

  // Calculate stats from real-time data
  const stats = useMemo(() => {
    const nearbyDonations = availableDonations.length;
    const requestedItems = deliveryRequests.filter(
      (req) => req.status === "pending" || req.status === "accepted"
    ).length;
    const receivedItems = deliveryRequests.filter(
      (req) => req.status === "completed"
    ).length;

    return { nearbyDonations, requestedItems, receivedItems };
  }, [availableDonations, deliveryRequests]);
  // --- Real-time recipient stats update ---
useEffect(() => {
  if (!user?.id) return;

  const statsRef = doc(db, "recipientStats", user.id);
  const unsubscribe = onSnapshot(statsRef, (docSnap) => {
    if (docSnap.exists()) {
      console.log("Recipient stats updated:", docSnap.data());
    }
  });

  return () => unsubscribe();
}, [user?.id]);

  // Filter donations based on search query
  const filteredDonations = useMemo(() => {
    if (!searchQuery.trim()) return availableDonations;

    const query = searchQuery.toLowerCase();
    return availableDonations.filter(
      (donation) =>
        donation.foodType.toLowerCase().includes(query) ||
        donation.location.toLowerCase().includes(query) ||
        donation.donorName.toLowerCase().includes(query)
    );
  }, [availableDonations, searchQuery]);

  // Calculate time until expiry
  const getExpiresIn = (expiresAt: any): string => {
  if (!expiresAt) return "N/A";

  const date =
    expiresAt instanceof Date
      ? expiresAt
      : expiresAt.toDate?.() || new Date(expiresAt);

  const now = new Date();
  const diffMs = date.getTime() - now.getTime();
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

  if (diffMs <= 0) return "Expired";
  if (diffHours > 0) return `${diffHours} hour${diffHours !== 1 ? "s" : ""}`;
  if (diffMins > 0) return `${diffMins} minute${diffMins !== 1 ? "s" : ""}`;
  return "Soon";
};


  // Map delivery requests to donation card format for display
  const requestedDonationCards = useMemo(() => {
    return deliveryRequests.map((request) => ({
      id: request.id,
      foodType: request.donationId, // Will be enhanced with actual donation data
      quantity: "",
      location: request.recipientAddress,
      expiresIn: "",
      status: request.status as "pending" | "available" | "assigned" | "completed" | "cancelled",
      donorName: "",
    }));
  }, [deliveryRequests]);

  const handleRequest = async (donationId: string) => {
  if (!user) {
    toast({
      title: "Authentication Required",
      description: "Please log in to request donations.",
      variant: "destructive",
    });
    return;
  }

  if (!user.address) {
    toast({
      title: "Address Required",
      description: "Please update your profile with an address before requesting donations.",
      variant: "destructive",
    });
    return;
  }

  const existingRequest = deliveryRequests.find(
  (req) => req.donationId === donationId && req.recipientId === user.id
);
if (existingRequest) {
  toast({
    title: "Duplicate Request",
    description: "You’ve already requested this donation.",
    variant: "destructive",
  });
  return;
}

try {
  setRequestingDonation(donationId);
  setAvailableDonations((prev) =>
    prev.map((d) =>
      d.id === donationId ? { ...d, status: "pending" } : d
    )
  );

    // Unified Firestore helper
    await requestDonation(donationId, {
  id: user.id,
  name: user.name,
  phone: user.phone,
  address: user.address || "",
  latitude: user.location?.lat || null,
  longitude: user.location?.lng || null,
});

    toast({
      title: "Request Submitted",
      description:
        "Your donation request has been submitted successfully. A volunteer will be assigned soon.",
    });
  } catch (error: any) {
    console.error("Error requesting donation:", error);
    toast({
      title: "Request Failed",
      description:
        error.message || "Failed to request donation. Please try again.",
      variant: "destructive",
    });
  } finally {
    setRequestingDonation(null);
  }
};

const handleMarkDelivered = async (requestId: string) => {
  try {
    console.log("Marking as delivered:", requestId);
    const docRef = doc(db, "deliveryRequests", requestId);

    const deliverySnap = await getDoc(docRef);
    if (!deliverySnap.exists()) throw new Error("Delivery not found");
    const delivery = deliverySnap.data();

    // ✅ 1. Update delivery request
    await updateDoc(docRef, {
      status: "completed",
      deliveredAt: new Date(),
    });

    // ✅ 2. Update related donation
if (!delivery.donationId) {
  console.warn("No donationId found for this delivery:", requestId);
  return;
}

const donationRef = doc(db, "donations", delivery.donationId);
await updateDoc(donationRef, {
  status: "completed",
  deliveredAt: new Date(),
});

    // ✅ 3. Update volunteer stats
    if (delivery.volunteerId) {
      const volunteerStatsRef = doc(db, "volunteerStats", delivery.volunteerId);
      const statsSnap = await getDoc(volunteerStatsRef);

      if (statsSnap.exists()) {
        const stats = statsSnap.data();
        await updateDoc(volunteerStatsRef, {
          activeDeliveries: Math.max((stats.activeDeliveries || 1) - 1, 0),
          completedDeliveries: (stats.completedDeliveries || 0) + 1,
          mealsDelivered: (stats.mealsDelivered || 0) + (delivery.meals || 0),
          distanceTraveled: (stats.distanceTraveled || 0) + (delivery.distance || 0),
          lastUpdated: new Date(),
        });
      } else {
        await setDoc(volunteerStatsRef, {
          volunteerId: delivery.volunteerId,
          activeDeliveries: 0,
          completedDeliveries: 1,
          mealsDelivered: delivery.meals || 0,
          distanceTraveled: delivery.distance || 0,
          lastUpdated: new Date(),
        });
      }
    }

    // ✅ 4. Update donor stats
    if (delivery.donorId) {
      const donorStatsRef = doc(db, "donorStats", delivery.donorId);
      const donorSnap = await getDoc(donorStatsRef);

      if (donorSnap.exists()) {
        const donorStats = donorSnap.data();
        await updateDoc(donorStatsRef, {
          completedDonations: (donorStats.completedDonations || 0) + 1,
          activeListings: Math.max((donorStats.activeListings || 1) - 1, 0),
          lastUpdated: new Date(),
        });
      } else {
        await setDoc(donorStatsRef, {
          donorId: delivery.donorId,
          completedDonations: 1,
          activeListings: 0,
          totalDonations: 1,
          impactScore: 1,
          lastUpdated: new Date(),
        });
      }
    }
    setDeliveryRequests((prev) =>
  prev.map((r) =>
    r.id === requestId ? { ...r, status: "completed" } : r
  )
);

    toast({
      title: "Delivery Completed",
      description: "All stats updated successfully!",
    });

  } catch (err: any) {
    console.error("Error marking delivery:", err);
    toast({
      title: "Update Failed",
      description: err.message || "Unable to update stats.",
      variant: "destructive",
    });
  }
};



  const handleLogout = async () => {
    try {
      await signOut();
      setLocation("/login");
    } catch (error) {
      console.error("Error logging out:", error);
      toast({
        title: "Logout Failed",
        description: "Failed to log out. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-muted/30 flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mx-auto"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-muted/30 flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Authentication Required</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-4">Please log in to access the recipient dashboard.</p>
            <Link href="/login">
              <Button className="w-full" data-testid="button-login">Go to Login</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted/30">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between px-4 mx-auto max-w-7xl">
          <div className="flex items-center gap-2">
            <div className="relative">
              <Heart className="h-6 w-6 text-primary fill-primary" />
              <div className="absolute -top-1 -right-1 w-2 h-2 bg-secondary rounded-full"></div>
            </div>
            <span className="font-display font-bold text-xl">Food<span className="text-primary">Connect</span></span>
            <span className="text-sm text-muted-foreground ml-2">/ Recipient Dashboard</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground" data-testid="text-username">Welcome, {user.name}</span>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => setLocation("/profile")}
              data-testid="button-profile"
            >
              <UserIcon className="h-4 w-4 mr-2" />
              Profile
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleLogout}
              data-testid="button-logout"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto max-w-7xl px-4 py-8">
        <div className="mb-8">
          <h1 className="font-display font-bold text-3xl mb-2">Recipient Dashboard</h1>
          <p className="text-muted-foreground">Browse available food donations near you</p>
        </div>

        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Database Configuration Required</AlertTitle>
            <AlertDescription>
              {error} The dashboard will still work, but some data may not load. Check the browser console for index creation links.
            </AlertDescription>
          </Alert>
        )}

        {!user.address && (
          <Alert className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Please update your profile with an address to request donations.
            </AlertDescription>
          </Alert>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {loadingDonations || loadingRequests ? (
            <>
              <Card>
                <CardContent className="pt-6">
                  <Skeleton className="h-12 w-12 mb-4" />
                  <Skeleton className="h-8 w-16 mb-2" />
                  <Skeleton className="h-4 w-32" />
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <Skeleton className="h-12 w-12 mb-4" />
                  <Skeleton className="h-8 w-16 mb-2" />
                  <Skeleton className="h-4 w-32" />
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <Skeleton className="h-12 w-12 mb-4" />
                  <Skeleton className="h-8 w-16 mb-2" />
                  <Skeleton className="h-4 w-32" />
                </CardContent>
              </Card>
            </>
          ) : (
            <>
              <StatCard 
                icon={MapPin} 
                value={stats.nearbyDonations.toString()} 
                label="Nearby Donations" 
                color="text-primary" 
              />
              <StatCard 
                icon={Package} 
                value={stats.requestedItems.toString()} 
                label="Requested" 
                color="text-secondary" 
              />
              <StatCard 
                icon={CheckCircle} 
                value={stats.receivedItems.toString()} 
                label="Received" 
                color="text-accent" 
              />
            </>
          )}
        </div>

        <div className="mb-6">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by food type or location..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              data-testid="input-search"
            />
          </div>
        </div>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Available Donations Near You</CardTitle>
          </CardHeader>
          <CardContent>
            {loadingDonations ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3].map((i) => (
                  <Card key={i}>
                    <CardHeader>
                      <Skeleton className="h-6 w-3/4 mb-2" />
                      <Skeleton className="h-4 w-1/2" />
                    </CardHeader>
                    <CardContent>
                      <Skeleton className="h-4 w-full mb-2" />
                      <Skeleton className="h-4 w-full mb-2" />
                      <Skeleton className="h-4 w-3/4" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : filteredDonations.length === 0 ? (
              <div className="text-center py-12">
                <Package className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">
                  {searchQuery ? "No donations found matching your search." : "No donations available at the moment."}
                </p>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredDonations.map((donation) => (
                  <DonationCard 
  key={donation.id} 
  id={donation.id}
  foodType={donation.foodType}
  quantity={donation.quantity}
  location={donation.locationName || donation.address || "Location not available"}
  expiresIn={getExpiresIn(donation.expiresAt)}
  status={donation.status}
  donorName={donation.donorName}
  donorPhone={donation.donorPhone}
  onRequest={() => handleRequest(donation.id)}
  isRequesting={requestingDonation === donation.id}
/>

                ))}
              </div>
            )}  
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Your Requests</CardTitle>
          </CardHeader>
          <CardContent>
            {loadingRequests ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2].map((i) => (
                  <Card key={i}>
                    <CardHeader>
                      <Skeleton className="h-6 w-3/4 mb-2" />
                      <Skeleton className="h-4 w-1/2" />
                    </CardHeader>
                    <CardContent>
                      <Skeleton className="h-4 w-full mb-2" />
                      <Skeleton className="h-4 w-full mb-2" />
                      <Skeleton className="h-4 w-3/4" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : deliveryRequests.length === 0 ? (
              <div className="text-center py-12">
                <Package className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">You haven't requested any donations yet.</p>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {deliveryRequests.map((request) => (
                  <Card key={request.id} className="hover-elevate" data-testid={`card-request-${request.id}`}>
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1">
                          <h3 className="font-semibold text-lg mb-1">Delivery Request</h3>
                          <p className={`text-sm font-medium ${
  request.status === "completed" ? "text-green-600" :
  request.status === "pending" ? "text-yellow-600" :
  "text-muted-foreground"
}`}>
  Status: {request.status}
</p>
                        </div>
                      </div>
                    </CardHeader>
                    
                    <CardContent className="space-y-3">
                      <div className="flex items-center gap-2 text-sm">
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                        <span className="text-foreground">{request.recipientAddress}</span>
                      </div>
                      {request.donorName && (
  <div className="flex items-center gap-2 text-sm">
    <Heart className="h-4 w-4 text-muted-foreground" />
    <span className="text-foreground">
      Donor: {request.donorName} ({request.donorPhone || "N/A"})
    </span>
  </div>
)}

                      {request.volunteerName && (
  <div className="flex items-center gap-2 text-sm">
    <Package className="h-4 w-4 text-muted-foreground" />
    <span className="text-foreground">
      Volunteer: {request.volunteerName} ({request.volunteerPhone || "N/A"})
    </span>
  </div>
)}

                      
                      {request.estimatedTime && (
                        <div className="flex items-center gap-2 text-sm">
                          <CheckCircle className="h-4 w-4 text-muted-foreground" />
                          <span className="text-foreground">ETA: {request.estimatedTime}</span>
                        </div>
                      )}
                      {request.status === "accepted" || request.status === "in_delivery" ? (
  <Button
    onClick={() => handleMarkDelivered(request.id)}
    className="w-full mt-3 bg-green-600 hover:bg-green-700"
  >
    Mark as Delivered
  </Button>
) : null}

                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Nearby Volunteers Map */}
        <div className="mt-8">
          <NearbyVolunteersMap />
        </div>
      </main>
    </div>
  );
}