import { useState, useEffect, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import StatCard from "@/components/StatCard";
import { Heart, Users, Package, AlertTriangle, LogOut, Search, Ban, Check, Upload, Download, User as UserIcon } from "lucide-react";
import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { signOut } from "@/lib/auth";
import {
  subscribeToUsers,
  subscribeToFraudAlerts,
  getAllDonations,
  getAllDeliveryRequests,
  updateUserStatus,
} from "@/lib/firestore";
import type { User, FraudAlert, Donation, DeliveryRequest } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export default function AdminDashboard() {
  const [, setLocation] = useLocation();
  const { user, isAdmin, loading: authLoading } = useAuth();
  const { toast } = useToast();
  
  const [searchQuery, setSearchQuery] = useState("");
  const [users, setUsers] = useState<User[]>([]);
  const [fraudAlerts, setFraudAlerts] = useState<FraudAlert[]>([]);
  const [donations, setDonations] = useState<Donation[]>([]);
  const [deliveryRequests, setDeliveryRequests] = useState<DeliveryRequest[]>([]);
  
  const [loadingUsers, setLoadingUsers] = useState(true);
  const [loadingAlerts, setLoadingAlerts] = useState(true);
  const [loadingStats, setLoadingStats] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [importing, setImporting] = useState(false);

  // Redirect if not admin
  useEffect(() => {
    if (!authLoading && !isAdmin) {
      setLocation("/login");
    }
  }, [authLoading, isAdmin, setLocation]);

  // Subscribe to users in real-time
  useEffect(() => {
    setLoadingUsers(true);
    const unsubscribe = subscribeToUsers((fetchedUsers) => {
      setUsers(fetchedUsers);
      setLoadingUsers(false);
    });
    
    return () => unsubscribe();
  }, []);

  // Subscribe to fraud alerts in real-time
  useEffect(() => {
    setLoadingAlerts(true);
    const unsubscribe = subscribeToFraudAlerts((fetchedAlerts) => {
      setFraudAlerts(fetchedAlerts);
      setLoadingAlerts(false);
    });
    
    return () => unsubscribe();
  }, []);

  // Fetch platform stats data
  useEffect(() => {
    const fetchStats = async () => {
      setLoadingStats(true);
      try {
        const [allDonations, allDeliveries] = await Promise.all([
          getAllDonations(),
          getAllDeliveryRequests(),
        ]);
        setDonations(allDonations);
        setDeliveryRequests(allDeliveries);
      } catch (error) {
        console.error("Error fetching stats:", error);
        toast({
          title: "Error",
          description: "Failed to load platform statistics",
          variant: "destructive",
        });
      } finally {
        setLoadingStats(false);
      }
    };

    fetchStats();
  }, [toast]);

  // Calculate platform stats
  const platformStats = useMemo(() => {
    const totalUsers = users.length;
    const activeDonations = donations.filter(
      (d) => d.status === "available" || d.status === "pending" || d.status === "assigned"
    ).length;
    const completedDeliveries = deliveryRequests.filter((d) => d.status === "completed").length;
    const fraudAlertsCount = fraudAlerts.length;

    return {
      totalUsers,
      activeDonations,
      completedDeliveries,
      fraudAlertsCount,
    };
  }, [users, donations, deliveryRequests, fraudAlerts]);

  // Filter users based on search query
  const filteredUsers = useMemo(() => {
    if (!searchQuery.trim()) return users;
    
    const query = searchQuery.toLowerCase();
    return users.filter(
      (user) =>
        user.name.toLowerCase().includes(query) ||
        user.email.toLowerCase().includes(query) ||
        user.role.toLowerCase().includes(query)
    );
  }, [users, searchQuery]);

  // Get user activity counts
  const getUserActivity = (userId: string, role: string) => {
    if (role === "donor") {
      const donationCount = donations.filter((d) => d.donorId === userId).length;
      return donationCount > 0 ? `${donationCount} donation${donationCount !== 1 ? "s" : ""}` : "No activity";
    } else if (role === "recipient") {
      const requestCount = deliveryRequests.filter((d) => d.recipientId === userId).length;
      return requestCount > 0 ? `${requestCount} request${requestCount !== 1 ? "s" : ""}` : "No activity";
    } else if (role === "volunteer") {
      const deliveryCount = deliveryRequests.filter((d) => d.volunteerId === userId).length;
      return deliveryCount > 0 ? `${deliveryCount} deliver${deliveryCount !== 1 ? "ies" : "y"}` : "No activity";
    }
    return "N/A";
  };

  const handleSuspendUser = async (userId: string) => {
    setActionLoading(userId);
    try {
      await updateUserStatus(userId, "suspended");
      toast({
        title: "User Suspended",
        description: "User has been successfully suspended",
      });
    } catch (error) {
      console.error("Error suspending user:", error);
      toast({
        title: "Error",
        description: "Failed to suspend user",
        variant: "destructive",
      });
    } finally {
      setActionLoading(null);
    }
  };

  const handleActivateUser = async (userId: string) => {
    setActionLoading(userId);
    try {
      await updateUserStatus(userId, "active");
      toast({
        title: "User Activated",
        description: "User has been successfully activated",
      });
    } catch (error) {
      console.error("Error activating user:", error);
      toast({
        title: "Error",
        description: "Failed to activate user",
        variant: "destructive",
      });
    } finally {
      setActionLoading(null);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut();
      setLocation("/login");
    } catch (error) {
      console.error("Error logging out:", error);
      toast({
        title: "Error",
        description: "Failed to logout",
        variant: "destructive",
      });
    }
  };

  const handleExportUsers = () => {
    // Export users to CSV
    const csvContent = [
      ["Name", "Email", "Role", "Status", "Phone", "Activity"].join(","),
      ...filteredUsers.map(user => [
        user.name,
        user.email,
        user.role,
        user.status,
        user.phone || "N/A",
        getUserActivity(user.id, user.role)
      ].join(",")),
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `foodconnect-users-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);

    toast({
      title: "Export Successful",
      description: `Exported ${filteredUsers.length} users to CSV`,
    });
  };

  const handleImportCSV = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setImporting(true);
    const reader = new FileReader();

    reader.onload = async (e) => {
      try {
        const text = e.target?.result as string;
        const lines = text.split("\n").filter(line => line.trim());
        
        // Skip header row
        const dataLines = lines.slice(1);
        
        let successCount = 0;
        let errorCount = 0;

        for (const line of dataLines) {
          try {
            const [name, email, role, status, phone] = line.split(",").map(s => s.trim());
            
            if (!name || !email || !role) {
              console.warn("Skipping invalid row:", line);
              errorCount++;
              continue;
            }

            // Note: This is a simplified import - in production you'd want to:
            // 1. Validate email format
            // 2. Check for duplicates
            // 3. Create Firebase auth accounts
            // 4. Use batch operations for efficiency
            
            toast({
              title: "Import Notice",
              description: "CSV import detected. Please implement full import logic with Firebase Auth integration.",
              variant: "destructive",
            });
            
            break; // Remove this when implementing full logic
          } catch (rowError) {
            console.error("Error processing row:", rowError);
            errorCount++;
          }
        }

        if (successCount > 0 || errorCount > 0) {
          toast({
            title: "Import Complete",
            description: `Successfully imported ${successCount} users. ${errorCount} errors.`,
          });
        }
      } catch (error) {
        console.error("Error importing CSV:", error);
        toast({
          title: "Import Failed",
          description: "Failed to parse CSV file",
          variant: "destructive",
        });
      } finally {
        setImporting(false);
        event.target.value = ""; // Reset file input
      }
    };

    reader.readAsText(file);
  };

  // Show loading skeleton while checking auth
  if (authLoading) {
    return (
      <div className="min-h-screen bg-muted/30">
        <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="container flex h-16 items-center justify-between px-4 mx-auto max-w-7xl">
            <Skeleton className="h-8 w-48" />
            <Skeleton className="h-8 w-32" />
          </div>
        </header>
        <main className="container mx-auto max-w-7xl px-4 py-8">
          <Skeleton className="h-10 w-64 mb-8" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="h-32" />
            ))}
          </div>
        </main>
      </div>
    );
  }

  // Don't render if not admin (will redirect)
  if (!isAdmin) {
    return null;
  }

  return (
    <div className="min-h-screen bg-muted/30">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between px-4 mx-auto max-w-7xl">
          <div className="flex items-center gap-2">
            <div className="relative">
              <Heart className="h-6 w-6 text-primary fill-primary" />
              <div className="absolute -top-1 -right-1 w-2 h-2 bg-secondary rounded-full"></div>
            </div>
            <span className="font-display font-bold text-xl">Food<span className="text-primary">Connect</span></span>
            <span className="text-sm text-muted-foreground ml-2">/ Admin Dashboard</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground" data-testid="text-admin-name">
              {user?.name || "Admin Panel"}
            </span>
            <Button variant="ghost" size="sm" onClick={() => setLocation("/profile")} data-testid="button-profile">
              <UserIcon className="h-4 w-4 mr-2" />
              Profile
            </Button>
            <Button variant="ghost" size="sm" onClick={handleLogout} data-testid="button-logout">
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto max-w-7xl px-4 py-8">
        <div className="mb-8">
          <h1 className="font-display font-bold text-3xl mb-2">Admin Dashboard</h1>
          <p className="text-muted-foreground">Monitor platform activity and manage users</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {loadingStats ? (
            <>
              {[1, 2, 3, 4].map((i) => (
                <Skeleton key={i} className="h-32" />
              ))}
            </>
          ) : (
            <>
              <StatCard
                icon={Users}
                value={platformStats.totalUsers.toString()}
                label="Total Users"
                color="text-primary"
                data-testid="stat-total-users"
              />
              <StatCard
                icon={Package}
                value={platformStats.activeDonations.toString()}
                label="Active Donations"
                color="text-secondary"
                data-testid="stat-active-donations"
              />
              <StatCard
                icon={Check}
                value={platformStats.completedDeliveries.toString()}
                label="Completed Deliveries"
                color="text-accent"
                data-testid="stat-completed-deliveries"
              />
              <StatCard
                icon={AlertTriangle}
                value={platformStats.fraudAlertsCount.toString()}
                label="Fraud Alerts"
                color="text-destructive"
                data-testid="stat-fraud-alerts"
              />
            </>
          )}
        </div>

        {loadingAlerts ? (
          <Skeleton className="h-48 mb-8" />
        ) : fraudAlerts.length > 0 ? (
          <Card className="mb-8 border-destructive">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-destructive">
                <AlertTriangle className="h-5 w-5" />
                Fraud Alerts
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {fraudAlerts.map((alert) => (
                  <div key={alert.id} className="p-4 rounded-lg border bg-destructive/5" data-testid={`fraud-alert-${alert.id}`}>
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <p className="font-semibold">{alert.userName}</p>
                          <Badge className={alert.severity === "high" ? "bg-destructive" : "bg-yellow-500"}>
                            {alert.severity}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">{alert.reason}</p>
                        <p className="text-xs text-muted-foreground mt-1">{alert.userEmail}</p>
                      </div>
                      <Button variant="outline" size="sm" data-testid={`button-review-alert-${alert.id}`}>
                        Review
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ) : null}

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between gap-4 flex-wrap">
              <CardTitle>User Management</CardTitle>
              <div className="flex items-center gap-2 flex-wrap">
                <div className="relative max-w-sm">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search users..."
                    className="pl-10"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    data-testid="input-search-users"
                  />
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleExportUsers}
                  disabled={users.length === 0}
                  data-testid="button-export-csv"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Export CSV
                </Button>
                <div className="relative">
                  <input
                    type="file"
                    accept=".csv"
                    onChange={handleImportCSV}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    disabled={importing}
                    data-testid="input-import-csv"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={importing}
                    data-testid="button-import-csv"
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    {importing ? "Importing..." : "Import CSV"}
                  </Button>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {loadingUsers ? (
              <div className="space-y-4">
                {[1, 2, 3, 4].map((i) => (
                  <Skeleton key={i} className="h-16" />
                ))}
              </div>
            ) : (
              <div className="rounded-lg border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Activity</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredUsers.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                          {searchQuery ? "No users found matching your search" : "No users registered yet"}
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredUsers.map((user) => (
                        <TableRow key={user.id} data-testid={`user-row-${user.id}`}>
                          <TableCell className="font-medium">{user.name}</TableCell>
                          <TableCell>{user.email}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{user.role}</Badge>
                          </TableCell>
                          <TableCell>
                            <Badge
                              className={
                                user.status === "active"
                                  ? "bg-green-500/10 text-green-700 dark:text-green-400"
                                  : user.status === "suspended"
                                  ? "bg-red-500/10 text-red-700 dark:text-red-400"
                                  : "bg-yellow-500/10 text-yellow-700 dark:text-yellow-400"
                              }
                            >
                              {user.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {getUserActivity(user.id, user.role)}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-2">
                              {user.status === "active" ? (
                                <Button
                                  variant="destructive"
                                  size="sm"
                                  onClick={() => handleSuspendUser(user.id)}
                                  disabled={actionLoading === user.id}
                                  data-testid={`button-suspend-${user.id}`}
                                >
                                  <Ban className="h-4 w-4 mr-2" />
                                  Block
                                </Button>
                              ) : (
                                <Button
                                  variant="default"
                                  size="sm"
                                  onClick={() => handleActivateUser(user.id)}
                                  disabled={actionLoading === user.id}
                                  data-testid={`button-activate-${user.id}`}
                                >
                                  <Check className="h-4 w-4 mr-2" />
                                  Unblock
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
