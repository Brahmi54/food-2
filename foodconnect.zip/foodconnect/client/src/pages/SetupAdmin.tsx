import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Heart, Shield, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { createUser, updateUser, getUser } from "@/lib/firestore";

export default function SetupAdmin() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [loading, setLoading] = useState(false);
  const [completed, setCompleted] = useState(false);

  const handleSetupAdmin = async () => {
    setLoading(true);

    try {
      // Create admin Firebase account
      const result = await createUserWithEmailAndPassword(
        auth,
        "admin@foodconnect.com",
        "admin@123"
      );

      // Create admin user document in Firestore
      await createUser(result.user.uid, {
        email: "admin@foodconnect.com",
        name: "Admin User",
        phone: "+91 9123456780",
        role: "admin",
        status: "active",
        lastActive: new Date(),
      });

      setCompleted(true);

      toast({
        title: "Admin Account Created! 🎉",
        description: "You can now login with admin credentials",
      });

      setTimeout(() => {
        setLocation("/login");
      }, 2000);
    } catch (error: any) {
      // If account already exists, ensure it has admin role
      if (error.code === "auth/email-already-in-use") {
        try {
          // Sign in to get the user ID
          const { signInWithEmail, signOut } = await import("@/lib/auth");
          const firebaseUser = await signInWithEmail("admin@foodconnect.com", "admin@123");
          
          // Update to ensure role is admin
          const adminUser = await getUser(firebaseUser.uid);
          if (!adminUser) {
            await createUser(firebaseUser.uid, {
              email: "admin@foodconnect.com",
              name: "Admin User",
              phone: "+91 9123456780",
              role: "admin",
              status: "active",
              lastActive: new Date(),
            });
          } else {
            await updateUser(firebaseUser.uid, {
              role: "admin",
              status: "active",
            });
          }

          // Sign out so user can login fresh with updated status
          await signOut();

          setCompleted(true);

          toast({
            title: "Admin Account Updated! ✅",
            description: "Please login with admin credentials",
          });

          setTimeout(() => {
            setLocation("/login");
          }, 1500);
        } catch (updateError: any) {
          toast({
            title: "Account Exists",
            description: "Please login with admin credentials",
          });
          setTimeout(() => {
            setLocation("/login");
          }, 1500);
        }
      } else {
        toast({
          title: "Setup Failed",
          description: error.message || "Failed to create admin account",
          variant: "destructive",
        });
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 mb-4">
            <div className="relative">
              <Heart className="h-8 w-8 text-primary fill-primary" />
              <div className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-secondary rounded-full"></div>
            </div>
            <span className="font-display font-bold text-2xl">
              Food<span className="text-primary">Connect</span>
            </span>
          </div>
          <h1 className="font-display font-bold text-3xl mb-2">Admin Setup</h1>
          <p className="text-muted-foreground">One-time administrator account creation</p>
        </div>

        <Card>
          <CardHeader>
            <div className="flex justify-center mb-4">
              <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
                <Shield className="h-8 w-8 text-primary" />
              </div>
            </div>
            <CardTitle className="text-center">Create Admin Account</CardTitle>
            <CardDescription className="text-center">
              Initialize the administrator account with default credentials
            </CardDescription>
          </CardHeader>

          <CardContent className="space-y-4">
            {!completed ? (
              <>
                <div className="bg-muted/50 rounded-lg p-4 space-y-2">
                  <p className="text-sm font-medium">Admin Credentials:</p>
                  <div className="space-y-1 text-sm text-muted-foreground">
                    <p><strong>Email:</strong> admin@foodconnect.com</p>
                    <p><strong>Password:</strong> admin@123</p>
                  </div>
                </div>

                <Button
                  onClick={handleSetupAdmin}
                  disabled={loading}
                  className="w-full"
                  size="lg"
                  data-testid="button-setup-admin"
                >
                  {loading ? (
                    <>
                      <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-background border-t-transparent"></div>
                      Creating Admin Account...
                    </>
                  ) : (
                    <>
                      <Shield className="mr-2 h-5 w-5" />
                      Create Admin Account
                    </>
                  )}
                </Button>

                <p className="text-xs text-center text-muted-foreground">
                  This is a one-time setup. You can change the password after logging in.
                </p>
              </>
            ) : (
              <div className="text-center py-8">
                <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Admin Account Ready!</h3>
                <p className="text-sm text-muted-foreground">
                  Redirecting to login page...
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
