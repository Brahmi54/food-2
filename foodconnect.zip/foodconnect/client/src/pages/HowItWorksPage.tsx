import Header from "@/components/Header";
import Footer from "@/components/Footer";
import HowItWorks from "@/components/HowItWorks";
import { Card, CardContent } from "@/components/ui/card";
import { Users, Heart, Shield, Clock } from "lucide-react";

export default function HowItWorksPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <section className="py-16 md:py-20 lg:py-24 bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5">
          <div className="container mx-auto max-w-7xl px-4">
            <div className="text-center mb-12">
              <h1 className="font-display font-bold text-4xl md:text-5xl mb-6">
                How FoodConnect Works
              </h1>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                Our platform makes it simple to connect surplus food with those
                who need it most
              </p>
            </div>
          </div>
        </section>

        <HowItWorks />

        <section className="py-16 md:py-20 lg:py-24 bg-muted/30">
          <div className="container mx-auto max-w-7xl px-4">
            <div className="text-center mb-12">
              <h2 className="font-display font-bold text-3xl md:text-4xl mb-4">
                Why Choose FoodConnect?
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                We provide the tools and security you need for successful food
                distribution
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              <Card>
                <CardContent className="p-6">
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                    <Shield className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-display font-semibold text-xl mb-2">
                    Verified & Secure
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    All users undergo email verification. Admin monitoring
                    ensures platform integrity and prevents fraud.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="w-12 h-12 rounded-lg bg-secondary/10 flex items-center justify-center mb-4">
                    <Clock className="h-6 w-6 text-secondary" />
                  </div>
                  <h3 className="font-display font-semibold text-xl mb-2">
                    Real-Time Updates
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Track deliveries live with Google Maps. Get instant
                    notifications about donation status and requests.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center mb-4">
                    <Users className="h-6 w-6 text-accent" />
                  </div>
                  <h3 className="font-display font-semibold text-xl mb-2">
                    Community Driven
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Connect with verified volunteers, donors, and recipients.
                    Build trust through transparent coordination.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                    <Heart className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-display font-semibold text-xl mb-2">
                    Social Impact
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Reduce food waste, feed communities, and contribute to
                    achieving Zero Hunger goals.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
