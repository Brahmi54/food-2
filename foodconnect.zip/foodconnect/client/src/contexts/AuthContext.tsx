import { createContext, useContext, useState, useEffect, type ReactNode } from "react";
import { type User as FirebaseUser } from "firebase/auth";
import { subscribeToAuthChanges } from "@/lib/auth";
import { getUser } from "@/lib/firestore";
import { auth } from "@/lib/firebase";
import type { User } from "@shared/schema";

interface AuthContextType {
  firebaseUser: FirebaseUser | null;
  user: User | null;
  currentUser: User | null;
  loading: boolean;
  isAuthenticated: boolean;
  isEmailVerified: boolean;
  isAdmin: boolean;
  isDonor: boolean;
  isRecipient: boolean;
  isVolunteer: boolean;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const refreshUser = async () => {
    if (firebaseUser) {
      try {
        // Don't reload here - let the caller do it if needed
        // Just force a state update with a new object reference
        const currentUser = auth.currentUser;
        if (currentUser) {
          setFirebaseUser({ ...currentUser });
          
          // Also refresh Firestore user data
          const userData = await getUser(currentUser.uid);
          setUser(userData);
        }
      } catch (error) {
        console.error("Error refreshing user data:", error);
      }
    }
  };

  useEffect(() => {
    const unsubscribe = subscribeToAuthChanges(async (fbUser) => {
      setFirebaseUser(fbUser);
      
      if (fbUser) {
        try {
          // Fetch user data from Firestore
          let userData = await getUser(fbUser.uid);
          
          // If no user data exists in Firestore yet, it might still be creating
          // This is normal for new registrations
          if (!userData) {
            // Wait a bit and try again (the Register page should have created it)
            await new Promise(resolve => setTimeout(resolve, 500));
            userData = await getUser(fbUser.uid);
          }
          
          setUser(userData);
        } catch (error) {
          console.error("Error fetching user data:", error);
          setUser(null);
        }
      } else {
        setUser(null);
      }
      
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

    const normalizedUser = user
    ? {
        uid: firebaseUser?.uid || user.uid,
        name: user.name || firebaseUser?.displayName || "Unknown",
        phone: user.phone || "",
        email: firebaseUser?.email || "",
        role: user.role || "guest",
      }
    : null;

  const value: AuthContextType = {
    firebaseUser,
    user,
    currentUser: normalizedUser,
    loading,
    isAuthenticated: !!firebaseUser && !!user,
    isEmailVerified: firebaseUser?.emailVerified || false,
    isAdmin: normalizedUser?.role === "admin",
    isDonor: normalizedUser?.role === "donor",
    isRecipient: normalizedUser?.role === "recipient",
    isVolunteer: normalizedUser?.role === "volunteer",
    refreshUser,
  };



  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
