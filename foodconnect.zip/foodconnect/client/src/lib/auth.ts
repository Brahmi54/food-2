import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  sendPasswordResetEmail,
  sendEmailVerification,
  onAuthStateChanged,
  type User as FirebaseUser,
} from "firebase/auth";
import { auth } from "./firebase";
import { createUser } from "./firestore";
import type { InsertUser } from "@shared/schema";

// Register new user with email and password (creates Firebase credential)
export const registerWithEmailAndPassword = async (
  email: string,
  password: string,
  userData: Omit<InsertUser, "email">
): Promise<void> => {
  try {
    // Create Firebase user account with email and password
    const result = await createUserWithEmailAndPassword(auth, email, password);
    
    // Send Firebase email verification link
    await sendEmailVerification(result.user);
    
    // Create user document in Firestore
    await createUser(result.user.uid, {
      ...userData,
      email,
    });
  } catch (error: any) {
    console.error("Error creating account:", error);
    throw new Error(error.message || "Failed to create account");
  }
};


// Sign in with email and password (for existing users who set password)
export const signInWithEmail = async (email: string, password: string): Promise<FirebaseUser> => {
  try {
    const result = await signInWithEmailAndPassword(auth, email, password);
    return result.user;
  } catch (error: any) {
    console.error("Error signing in:", error);
    throw new Error(error.message || "Failed to sign in");
  }
};


// Sign out
export const signOut = async (): Promise<void> => {
  try {
    await firebaseSignOut(auth);
  } catch (error: any) {
    console.error("Error signing out:", error);
    throw new Error(error.message || "Failed to sign out");
  }
};

// Send password reset email
export const sendPasswordReset = async (email: string): Promise<void> => {
  try {
    await sendPasswordResetEmail(auth, email);
  } catch (error: any) {
    console.error("Error sending password reset:", error);
    throw new Error(error.message || "Failed to send password reset email");
  }
};

// Subscribe to auth state changes
export const subscribeToAuthChanges = (
  callback: (user: FirebaseUser | null) => void
): (() => void) => {
  return onAuthStateChanged(auth, callback);
};
