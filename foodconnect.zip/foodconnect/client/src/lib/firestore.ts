import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  Timestamp,
  type WhereFilterOp,
  type DocumentData,
  onSnapshot,
  type Unsubscribe,
} from "firebase/firestore";
import { db } from "./firebase";
import type {
  User,
  InsertUser,
  Donation,
  InsertDonation,
  DeliveryRequest,
  InsertDeliveryRequest,
  VolunteerStats,
  DonorStats,
  RecipientStats,
  FraudAlert,
  InsertFraudAlert,
  PlatformStats,
} from "@shared/schema";

// Helper to convert Firestore Timestamp to Date
const convertTimestamps = (data: DocumentData): any => {
  const converted: any = { ...data };
  for (const key in converted) {
    if (converted[key] instanceof Timestamp) {
      converted[key] = converted[key].toDate();
    }
  }
  return converted;
};

// Helper to convert Date to Firestore Timestamp
const convertDates = (data: any): DocumentData => {
  const converted: any = { ...data };
  for (const key in converted) {
    if (converted[key] instanceof Date) {
      converted[key] = Timestamp.fromDate(converted[key]);
    }
  }
  return converted;
};

// Helper to remove undefined fields
const removeUndefined = (obj: any): any => {
  const cleaned: any = {};
  for (const key in obj) {
    if (obj[key] !== undefined) {
      cleaned[key] = obj[key];
    }
  }
  return cleaned;
};

// User Operations
export const createUser = async (userId: string, userData: InsertUser): Promise<void> => {
  const userRef = doc(db, "users", userId);
  const user = removeUndefined({
    ...userData,
    id: userId,
    createdAt: Timestamp.now(),
  });
  await setDoc(userRef, convertDates(user));
};


export const getUser = async (userId: string): Promise<User | null> => {
  const userRef = doc(db, "users", userId);
  const userSnap = await getDoc(userRef);
  if (!userSnap.exists()) return null;
  return convertTimestamps({ ...userSnap.data(), id: userSnap.id }) as User;
};

export const updateUser = async (userId: string, updates: Partial<User>): Promise<void> => {
  const userRef = doc(db, "users", userId);
  await updateDoc(userRef, convertDates(removeUndefined(updates)));
};

export const getAllUsers = async (): Promise<User[]> => {
  const usersRef = collection(db, "users");
  const snapshot = await getDocs(usersRef);
  return snapshot.docs.map((doc) => convertTimestamps({ ...doc.data(), id: doc.id }) as User);
};

export const updateUserStatus = async (userId: string, status: "active" | "suspended" | "flagged"): Promise<void> => {
  await updateUser(userId, { status });
};

// Donation Operations
export const createDonation = async (donationData: InsertDonation): Promise<string> => {
  const donationsRef = collection(db, "donations");
  const donationRef = doc(donationsRef);

  // 🔹 Get coordinates from donor address
  let lat = 0, lng = 0;
  if (donationData.address) {
    const coords = await getCoordinatesFromAddress(donationData.address);
    lat = coords.lat;
    lng = coords.lng;
  }

  const donation = {
  ...donationData,
  id: donationRef.id,
  status: "available" as const,
  createdAt: Timestamp.now(),
  donorLatitude: lat,
  donorLongitude: lng,
  location: { lat, lng },
};

  await setDoc(donationRef, convertDates(donation));
  return donationRef.id;
};
// Example geocoding step using Google Maps API
// 🌍 Convert address → coordinates using Google Maps API
async function getCoordinatesFromAddress(address: string) {
  if (!address) return { lat: 0, lng: 0 };

  try {
    const response = await fetch(
      `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(address)}&key=${
        import.meta.env.VITE_GOOGLE_MAPS_API_KEY
      }`
    );
    const data = await response.json();

    if (data.status === "OK" && data.results.length > 0) {
      const { lat, lng } = data.results[0].geometry.location;
      return { lat, lng };
    } else {
      console.warn("Geocode error:", data.status, address);
      return { lat: 0, lng: 0 };
    }
  } catch (error) {
    console.error("Error fetching coordinates:", error);
    return { lat: 0, lng: 0 };
  }
}
// Recipient requests a donation
export const requestDonation = async (
  donationId: string,
  recipient: { 
    id: string; 
    name?: string; 
    phone?: string; 
    address?: string; 
    latitude?: number; 
    longitude?: number; 
  }
): Promise<{ deliveryRequestId: string }> => {
  if (!donationId) throw new Error("Donation ID missing");
  if (!recipient?.id) throw new Error("Recipient ID missing");

  const donationRef = doc(db, "donations", donationId);
  const donationSnap = await getDoc(donationRef);
  if (!donationSnap.exists()) throw new Error("Donation not found");

  const donation = convertTimestamps({ ...donationSnap.data(), id: donationSnap.id }) as Donation;

  if (donation.status !== "available") {
    throw new Error("Donation is not available for request.");
  }

  const safeRecipient = {
    id: recipient.id,
    name: recipient.name?.trim() || "Recipient",
    phone: recipient.phone?.trim() || "",
  };

  let recipientLat = 0, recipientLng = 0;
  if (recipient.address) {
    const coords = await getCoordinatesFromAddress(recipient.address);
    recipientLat = coords.lat;
    recipientLng = coords.lng;
  }

  // Update donation → pending
  await updateDoc(donationRef, convertDates(removeUndefined({
    status: "pending",
    requestedBy: safeRecipient,
    recipientId: safeRecipient.id,
    recipientName: safeRecipient.name,
    recipientPhone: safeRecipient.phone,
    requestedAt: Timestamp.now(),
  })));

  // Create delivery request
  const deliveriesRef = collection(db, "deliveryRequests");
  const deliveryRef = doc(deliveriesRef);

  const delivery = removeUndefined({
    id: deliveryRef.id,
    donationId,

    donorId: donation.donorId || "",
    donorName: donation.donorName || "",
    donorPhone: donation.donorPhone || "",
    donorAddress: donation.address || "",
    donorLatitude: donation.location?.lat || 0,
    donorLongitude: donation.location?.lng || 0,
    pickupAddress: donation.address || "",
    pickupLocationName: donation.locationName || "",
    pickupLatitude: donation.location?.lat || 0,
    pickupLongitude: donation.location?.lng || 0,

    recipientId: safeRecipient.id,
    recipientName: safeRecipient.name,
    recipientPhone: safeRecipient.phone,
    recipientAddress: recipient.address || "",
    recipientLatitude: recipientLat || recipient.latitude || 0,
    recipientLongitude: recipientLng || recipient.longitude || 0,

    status: "pending" as const,
    createdAt: Timestamp.now(),
  });

  await setDoc(deliveryRef, convertDates(delivery));

  // Update recipient stats
  try {
    await updateRecipientStats(recipient.id, { requestedItems: 1 });
  } catch (err) {
    console.warn("Failed to update recipient stats:", err);
  }

  return { deliveryRequestId: deliveryRef.id };
};

export const getDonation = async (donationId: string): Promise<Donation | null> => {
  const donationRef = doc(db, "donations", donationId);
  const donationSnap = await getDoc(donationRef);
  if (!donationSnap.exists()) return null;
  return convertTimestamps({ ...donationSnap.data(), id: donationSnap.id }) as Donation;
};

export const updateDonation = async (donationId: string, updates: Partial<Donation>): Promise<void> => {
  const donationRef = doc(db, "donations", donationId);
  await updateDoc(donationRef, convertDates(removeUndefined(updates)));
};

export const getDonationsByDonor = async (donorId: string): Promise<Donation[]> => {
  const donationsRef = collection(db, "donations");
  const q = query(donationsRef, where("donorId", "==", donorId), orderBy("createdAt", "desc"));
  const snapshot = await getDocs(q);
  return snapshot.docs.map((doc) => convertTimestamps({ ...doc.data(), id: doc.id }) as Donation);
};

export const getAvailableDonations = async (): Promise<Donation[]> => {
  const donationsRef = collection(db, "donations");
  const q = query(donationsRef, where("status", "==", "available"), orderBy("createdAt", "desc"));
  const snapshot = await getDocs(q);
  return snapshot.docs.map((doc) => convertTimestamps({ ...doc.data(), id: doc.id }) as Donation);
};

export const subscribeToDonations = (
  filters: { status?: string; donorId?: string },
  callback: (donations: Donation[]) => void,
  onError?: (error: Error) => void
): Unsubscribe => {
  const donationsRef = collection(db, "donations");
  let q = query(donationsRef, orderBy("createdAt", "desc"));

  if (filters.status) {
    q = query(donationsRef, where("status", "==", filters.status), orderBy("createdAt", "desc"));
  } else if (filters.donorId) {
    q = query(donationsRef, where("donorId", "==", filters.donorId), orderBy("createdAt", "desc"));
  }

  return onSnapshot(
    q,
    (snapshot) => {
      const donations = snapshot.docs.map((doc) =>
        convertTimestamps({ ...doc.data(), id: doc.id }) as Donation
      );
      callback(donations);
    },
    (error) => {
      console.error("Error in donations subscription:", error);
      if (onError) {
        onError(error);
      } else {
        // Call callback with empty array on error so UI doesn't hang
        callback([]);
      }
    }
  );
};

// Delivery Request Operations
export const createDeliveryRequest = async (deliveryData: InsertDeliveryRequest): Promise<string> => {
  const deliveriesRef = collection(db, "deliveryRequests");
  const deliveryRef = doc(deliveriesRef);

  const delivery = removeUndefined({
  ...deliveryData,
  id: deliveryRef.id,

  // 🔹 Donor Info
  // 🔹 Donor Info
donorId: deliveryData.donorId || "",
donorName: deliveryData.donorName || "",
donorPhone: deliveryData.donorPhone || "",
donorAddress: deliveryData.donorAddress || "",
donorLatitude: deliveryData.donorLatitude || undefined,
donorLongitude: deliveryData.donorLongitude || undefined,

  // 🔹 Recipient Info
  recipientId: deliveryData.recipientId || "",
  recipientName: deliveryData.recipientName || "",
  recipientPhone: deliveryData.recipientPhone || "",
  recipientAddress: deliveryData.recipientAddress || "",
  recipientLatitude: deliveryData.recipientLatitude || undefined,
  recipientLongitude: deliveryData.recipientLongitude || undefined,

  // 🔹 Pickup Info
  pickupAddress: deliveryData.pickupAddress || "",
  pickupLocationName: deliveryData.pickupLocationName || "",

  // 🔹 Meta
  status: "pending" as const,
  createdAt: Timestamp.now(),
});

  await setDoc(deliveryRef, convertDates(delivery));
  return deliveryRef.id;
};

export const getDeliveryRequest = async (deliveryId: string): Promise<DeliveryRequest | null> => {
  const deliveryRef = doc(db, "deliveryRequests", deliveryId);
  const deliverySnap = await getDoc(deliveryRef);
  if (!deliverySnap.exists()) return null;
  return convertTimestamps({ ...deliverySnap.data(), id: deliverySnap.id }) as DeliveryRequest;
};

export const updateDeliveryRequest = async (deliveryId: string, updates: Partial<DeliveryRequest>): Promise<void> => {
  const deliveryRef = doc(db, "deliveryRequests", deliveryId);
  await updateDoc(deliveryRef, convertDates(removeUndefined(updates)));
};
/**
 * Called when a volunteer accepts a delivery request.
 * Updates both the delivery and related donation with volunteer info.
 */
export const acceptDeliveryByVolunteer = async (
  deliveryId: string,
  volunteer: { id: string; name: string; phone: string }
): Promise<void> => {
  if (!deliveryId || !volunteer?.id) throw new Error("Missing delivery or volunteer info");

  // Get delivery
  const deliveryRef = doc(db, "deliveryRequests", deliveryId);
  const deliverySnap = await getDoc(deliveryRef);
  if (!deliverySnap.exists()) throw new Error("Delivery not found");
  const delivery = deliverySnap.data();

  // Update delivery with volunteer info
  await updateDoc(
    deliveryRef,
    removeUndefined({
      status: "accepted",
      volunteerId: volunteer.id,
      volunteerName: volunteer.name,
      volunteerPhone: volunteer.phone,
      acceptedAt: Timestamp.now(),
    })
  );

  // Also update related donation
  if (delivery.donationId) {
    const donationRef = doc(db, "donations", delivery.donationId);
    await updateDoc(
      donationRef,
      removeUndefined({
        status: "out-for-delivery",
        volunteerId: volunteer.id,
        volunteerName: volunteer.name,
        volunteerPhone: volunteer.phone,
      })
    );
  }
};

export const getDeliveriesByVolunteer = async (volunteerId: string): Promise<DeliveryRequest[]> => {
  const deliveriesRef = collection(db, "deliveryRequests");
  const q = query(deliveriesRef, where("volunteerId", "==", volunteerId), orderBy("createdAt", "desc"));
  const snapshot = await getDocs(q);
  return snapshot.docs.map((doc) => convertTimestamps({ ...doc.data(), id: doc.id }) as DeliveryRequest);
};

export const getPendingDeliveries = async (): Promise<DeliveryRequest[]> => {
  const deliveriesRef = collection(db, "deliveryRequests");
  const q = query(deliveriesRef, where("status", "==", "pending"), orderBy("createdAt", "desc"));
  const snapshot = await getDocs(q);
  return snapshot.docs.map((doc) => convertTimestamps({ ...doc.data(), id: doc.id }) as DeliveryRequest);
};

export const getDeliveriesByRecipient = async (recipientId: string): Promise<DeliveryRequest[]> => {
  const deliveriesRef = collection(db, "deliveryRequests");
  const q = query(deliveriesRef, where("recipientId", "==", recipientId), orderBy("createdAt", "desc"));
  const snapshot = await getDocs(q);
  return snapshot.docs.map((doc) => convertTimestamps({ ...doc.data(), id: doc.id }) as DeliveryRequest);
};
/**
 * Called when the volunteer clicks "Delivered"
 * Updates both delivery & donation statuses.
 */
export const markDeliveryCompleted = async (deliveryId: string): Promise<void> => {
  const deliveryRef = doc(db, "deliveryRequests", deliveryId);
  const deliverySnap = await getDoc(deliveryRef);
  if (!deliverySnap.exists()) throw new Error("Delivery not found");

  const delivery = deliverySnap.data();

  // Update delivery
  await updateDoc(
    deliveryRef,
    removeUndefined({
      status: "delivered",
      deliveredAt: Timestamp.now(),
    })
  );

  // Update linked donation
  if (delivery.donationId) {
    const donationRef = doc(db, "donations", delivery.donationId);
    await updateDoc(
      donationRef,
      removeUndefined({
        status: "delivered",
        deliveredAt: Timestamp.now(),
      })
    );
  }
};

export const subscribeToDeliveries = (
  filters: { volunteerId?: string; recipientId?: string; status?: string },
  callback: (deliveries: DeliveryRequest[]) => void,
  onError?: (error: Error) => void
): Unsubscribe => {
  const deliveriesRef = collection(db, "deliveryRequests");
  let q = query(deliveriesRef, orderBy("createdAt", "desc"));

  if (filters.volunteerId && filters.status) {
    q = query(deliveriesRef, where("volunteerId", "==", filters.volunteerId), where("status", "==", filters.status), orderBy("createdAt", "desc"));
  } else if (filters.volunteerId) {
    q = query(deliveriesRef, where("volunteerId", "==", filters.volunteerId), orderBy("createdAt", "desc"));
  } else if (filters.recipientId) {
    q = query(deliveriesRef, where("recipientId", "==", filters.recipientId), orderBy("createdAt", "desc"));
  } else if (filters.status) {
    q = query(deliveriesRef, where("status", "==", filters.status), orderBy("createdAt", "desc"));
  }

  return onSnapshot(
    q,
    (snapshot) => {
      const deliveries = snapshot.docs.map((doc) =>
        convertTimestamps({ ...doc.data(), id: doc.id }) as DeliveryRequest
      );
      callback(deliveries);
    },
    (error) => {
      console.error("Error in deliveries subscription:", error);
      if (onError) {
        onError(error);
      } else {
        // Call callback with empty array on error so UI doesn't hang
        callback([]);
      }
    }
  );
};

// Stats Operations
export const getOrCreateVolunteerStats = async (volunteerId: string): Promise<VolunteerStats> => {
  const statsRef = doc(db, "volunteerStats", volunteerId);
  const statsSnap = await getDoc(statsRef);
  
  if (!statsSnap.exists()) {
    const newStats: VolunteerStats = {
      volunteerId,
      activeDeliveries: 0,
      completedDeliveries: 0,
      distanceTraveled: 0,
      mealsDelivered: 0,
      lastUpdated: new Date(),
    };
    await setDoc(statsRef, convertDates(newStats));
    return newStats;
  }
  
  return convertTimestamps(statsSnap.data()) as VolunteerStats;
};

export const updateVolunteerStats = async (volunteerId: string, updates: Partial<VolunteerStats>): Promise<void> => {
  const statsRef = doc(db, "volunteerStats", volunteerId);
  await updateDoc(statsRef, convertDates({ ...updates, lastUpdated: new Date() }));
};

export const getOrCreateDonorStats = async (donorId: string): Promise<DonorStats> => {
  const statsRef = doc(db, "donorStats", donorId);
  const statsSnap = await getDoc(statsRef);
  
  if (!statsSnap.exists()) {
    const newStats: DonorStats = {
      donorId,
      totalDonations: 0,
      activeListings: 0,
      completedDonations: 0,
      impactScore: 0,
      lastUpdated: new Date(),
    };
    await setDoc(statsRef, convertDates(newStats));
    return newStats;
  }
  
  return convertTimestamps(statsSnap.data()) as DonorStats;
};

export async function updateDonorStats(donorId: string, updates: Partial<DonorStats>) {
  const donorStatsRef = doc(db, "donorStats", donorId);
  await setDoc(donorStatsRef, { ...updates, lastUpdated: new Date() }, { merge: true });
}

export const getOrCreateRecipientStats = async (recipientId: string): Promise<RecipientStats> => {
  const statsRef = doc(db, "recipientStats", recipientId);
  const statsSnap = await getDoc(statsRef);
  
  if (!statsSnap.exists()) {
    const newStats: RecipientStats = {
      recipientId,
      nearbyDonations: 0,
      requestedItems: 0,
      receivedItems: 0,
      lastUpdated: new Date(),
    };
    await setDoc(statsRef, convertDates(newStats));
    return newStats;
  }
  
  return convertTimestamps(statsSnap.data()) as RecipientStats;
};

export const updateRecipientStats = async (recipientId: string, updates: Partial<RecipientStats>): Promise<void> => {
  const statsRef = doc(db, "recipientStats", recipientId);
  await updateDoc(statsRef, convertDates({ ...updates, lastUpdated: new Date() }));
};

// Fraud Alert Operations
export const createFraudAlert = async (alertData: InsertFraudAlert): Promise<string> => {
  const alertsRef = collection(db, "fraudAlerts");
  const alertRef = doc(alertsRef);
  const alert = {
    ...alertData,
    id: alertRef.id,
    status: "open" as const,
    createdAt: Timestamp.now(),
  };
  await setDoc(alertRef, convertDates(alert));
  return alertRef.id;
};

export const getFraudAlerts = async (): Promise<FraudAlert[]> => {
  const alertsRef = collection(db, "fraudAlerts");
  const q = query(alertsRef, where("status", "in", ["open", "investigating"]), orderBy("createdAt", "desc"));
  const snapshot = await getDocs(q);
  return snapshot.docs.map((doc) => convertTimestamps({ ...doc.data(), id: doc.id }) as FraudAlert);
};

export const updateFraudAlert = async (alertId: string, updates: Partial<FraudAlert>): Promise<void> => {
  const alertRef = doc(db, "fraudAlerts", alertId);
  await updateDoc(alertRef, convertDates(removeUndefined(updates)));
};

// Platform Stats Operations
export const getOrCreatePlatformStats = async (): Promise<PlatformStats> => {
  const statsRef = doc(db, "platformStats", "global");
  const statsSnap = await getDoc(statsRef);
  
  if (!statsSnap.exists()) {
    const newStats: PlatformStats = {
      totalUsers: 0,
      activeDonations: 0,
      completedDeliveries: 0,
      fraudAlertsCount: 0,
      lastUpdated: new Date(),
    };
    await setDoc(statsRef, convertDates(newStats));
    return newStats;
  }
  
  return convertTimestamps(statsSnap.data()) as PlatformStats;
};

export const updatePlatformStats = async (updates: Partial<PlatformStats>): Promise<void> => {
  const statsRef = doc(db, "platformStats", "global");
  await updateDoc(statsRef, convertDates({ ...updates, lastUpdated: new Date() }));
};

// Real-time subscriptions for admin
export const subscribeToUsers = (callback: (users: User[]) => void): Unsubscribe => {
  const usersRef = collection(db, "users");
  const q = query(usersRef, orderBy("createdAt", "desc"));
  
  return onSnapshot(q, (snapshot) => {
    const users = snapshot.docs.map((doc) =>
      convertTimestamps({ ...doc.data(), id: doc.id }) as User
    );
    callback(users);
  });
};

export const subscribeToFraudAlerts = (callback: (alerts: FraudAlert[]) => void): Unsubscribe => {
  const alertsRef = collection(db, "fraudAlerts");
  const q = query(alertsRef, where("status", "in", ["open", "investigating"]), orderBy("createdAt", "desc"));
  
  return onSnapshot(q, (snapshot) => {
    const alerts = snapshot.docs.map((doc) =>
      convertTimestamps({ ...doc.data(), id: doc.id }) as FraudAlert
    );
    callback(alerts);
  });
};

// Get all donations for counting
export const getAllDonations = async (): Promise<Donation[]> => {
  const donationsRef = collection(db, "donations");
  const snapshot = await getDocs(donationsRef);
  return snapshot.docs.map((doc) => convertTimestamps({ ...doc.data(), id: doc.id }) as Donation);
};

// Get all delivery requests for counting
export const getAllDeliveryRequests = async (): Promise<DeliveryRequest[]> => {
  const deliveriesRef = collection(db, "deliveryRequests");
  const snapshot = await getDocs(deliveriesRef);
  return snapshot.docs.map((doc) => convertTimestamps({ ...doc.data(), id: doc.id }) as DeliveryRequest);
};

// Get users by role with location data
export const getUsersByRole = async (role: string): Promise<User[]> => {
  const usersRef = collection(db, "users");
  const q = query(usersRef, where("role", "==", role));
  const snapshot = await getDocs(q);
  return snapshot.docs.map((doc) => convertTimestamps({ ...doc.data(), id: doc.id }) as User);
};

// Get nearby volunteers (volunteers with location data)
export const getNearbyVolunteers = async (): Promise<User[]> => {
  const volunteers = await getUsersByRole("volunteer");
  return volunteers.filter((volunteer) => volunteer.location !== undefined);
};

// Update user location (for real-time tracking)
export const updateUserLocation = async (userId: string, lat: number, lng: number): Promise<void> => {
  const userRef = doc(db, "users", userId);
  await updateDoc(userRef, {
    location: { lat, lng },
    lastActive: Timestamp.now(),
  });
};
