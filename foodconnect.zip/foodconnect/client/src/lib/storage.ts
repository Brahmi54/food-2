import { ref, uploadBytes, getDownloadURL, deleteObject } from "firebase/storage";
import { storage } from "./firebase";

/**
 * Upload a profile image to Firebase Storage
 * @param userId - The user's ID
 * @param file - The image file to upload
 * @returns The download URL of the uploaded image
 */
export const uploadProfileImage = async (userId: string, file: File): Promise<string> => {
  // Create a reference to the storage location
  const storageRef = ref(storage, `profile-images/${userId}/${Date.now()}-${file.name}`);
  
  // Upload the file
  await uploadBytes(storageRef, file);
  
  // Get and return the download URL
  const downloadURL = await getDownloadURL(storageRef);
  return downloadURL;
};

/**
 * Delete a profile image from Firebase Storage
 * @param imageUrl - The full URL of the image to delete
 */
export const deleteProfileImage = async (imageUrl: string): Promise<void> => {
  try {
    // Extract the path from the URL
    const imageRef = ref(storage, imageUrl);
    await deleteObject(imageRef);
  } catch (error) {
    console.error("Error deleting profile image:", error);
    // Don't throw - deletion errors shouldn't block profile updates
  }
};
