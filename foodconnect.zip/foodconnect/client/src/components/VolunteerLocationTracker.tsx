import { useState, useEffect, useRef } from "react";
import { GoogleMap, LoadScript, Marker, Polyline } from "@react-google-maps/api";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { MapPin, AlertCircle } from "lucide-react";
import { updateUserLocation } from "@/lib/firestore";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { db } from "@/lib/firebase";
import { doc, updateDoc, getDoc } from "firebase/firestore";

const mapContainerStyle = {
  width: "100%",
  height: "420px",
  borderRadius: "0.75rem",
};

export default function VolunteerLocationTracker() {
  const { user } = useAuth();
  const { toast } = useToast();
  const mapRef = useRef(null);

  const [currentLocation, setCurrentLocation] = useState(null);
  const [donorLocation, setDonorLocation] = useState(null);
  const [recipientLocation, setRecipientLocation] = useState(null);
  const [trackingError, setTrackingError] = useState(null);

  // 🚫 Stop processing if not volunteer
  if (!user || user.role !== "volunteer") return null;

  // 🛰️ Real-time volunteer location tracking
  useEffect(() => {
    if (!navigator.geolocation) {
      setTrackingError("Geolocation is not supported by your browser");
      return;
    }

    const watchId = navigator.geolocation.watchPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        const newLocation = { lat: latitude, lng: longitude };
        setCurrentLocation(newLocation);
        setTrackingError(null);

        try {
          if (!user?.id) return;

          // 1️⃣ Update volunteer’s live location in Firestore
          await updateUserLocation(user.id, latitude, longitude);

          // 2️⃣ Update active delivery info
          if (user.activeDeliveryId) {
            const deliveryRef = doc(db, "deliveryRequests", user.activeDeliveryId);
            await updateDoc(deliveryRef, {
              volunteerLatitude: latitude,
              volunteerLongitude: longitude,
              lastUpdated: new Date(),
            });

            const deliverySnap = await getDoc(deliveryRef);
            if (deliverySnap.exists()) {
              const data = deliverySnap.data();
              const donationId = data?.donationId;

              // 🟢 Donor coordinates
              if (data.donorLatitude && data.donorLongitude) {
                setDonorLocation({ lat: data.donorLatitude, lng: data.donorLongitude });
              }

              // 🔴 Recipient coordinates
              if (data.recipientLatitude && data.recipientLongitude) {
                setRecipientLocation({ lat: data.recipientLatitude, lng: data.recipientLongitude });
              }

              // 3️⃣ Update linked donation record with volunteer’s live position
              if (donationId) {
                const donationRef = doc(db, "donations", donationId);
                await updateDoc(donationRef, {
                  volunteerLatitude: latitude,
                  volunteerLongitude: longitude,
                  lastUpdated: new Date(),
                });
              }
            }
          }
        } catch (error) {
          console.error("Error updating volunteer location:", error);
        }
      },
      (error) => {
        console.error("Geolocation error:", error);
        let msg = "Unable to retrieve your location.";

        switch (error.code) {
          case error.PERMISSION_DENIED:
            msg = "Location permission denied. Please enable location access.";
            break;
          case error.POSITION_UNAVAILABLE:
            msg = "Location information unavailable.";
            break;
          case error.TIMEOUT:
            msg = "Location request timed out.";
            break;
        }

        setTrackingError(msg);
        toast({ title: "Location Error", description: msg, variant: "destructive" });
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 30000,
      }
    );

    return () => {
      navigator.geolocation.clearWatch(watchId);
      console.log("🛑 Stopped tracking volunteer location");
    };
  }, [user, toast]);

  // 🧭 Auto-zoom to fit donor, volunteer, and recipient
  useEffect(() => {
    if (!mapRef.current) return;
    const points = [currentLocation, donorLocation, recipientLocation].filter(Boolean);
    if (points.length > 0 && window.google?.maps) {
      const bounds = new window.google.maps.LatLngBounds();
      points.forEach((p) => bounds.extend(p));
      mapRef.current.fitBounds(bounds);
      mapRef.current.panToBounds(bounds); // smoother centering
    }
  }, [currentLocation, donorLocation, recipientLocation]);

  const mapCenter = currentLocation || { lat: 17.385044, lng: 78.486671 }; // Hyderabad fallback

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MapPin className="h-5 w-5 text-primary" />
          Volunteer Delivery Tracker
        </CardTitle>
        <CardDescription>
          Track your live delivery route between donor and recipient.
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        {trackingError && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{trackingError}</AlertDescription>
          </Alert>
        )}

        {currentLocation && (
          <Alert>
            <MapPin className="h-4 w-4" />
            <AlertDescription>
              Live tracking active — your location is visible on the map.
              <div className="text-xs mt-2 text-muted-foreground">
                Lat: {currentLocation.lat.toFixed(6)}, Lng: {currentLocation.lng.toFixed(6)}
              </div>
            </AlertDescription>
          </Alert>
        )}

        {/* 🗺️ Google Map Rendering */}
        <LoadScript googleMapsApiKey={import.meta.env.VITE_GOOGLE_MAPS_API_KEY}>
          <GoogleMap
            mapContainerStyle={mapContainerStyle}
            center={mapCenter}
            zoom={13}
            onLoad={(map) => (mapRef.current = map)}
          >
            {/* 🔵 Volunteer marker */}
            {currentLocation && (
              <Marker
                position={currentLocation}
                label={{ text: "Volunteer", color: "white", fontWeight: "bold" }}
                icon={{
                  url: "http://maps.google.com/mapfiles/ms/icons/blue-dot.png",
                  scaledSize: new window.google.maps.Size(40, 40),
                }}
              />
            )}

            {/* 🟢 Donor marker */}
            {donorLocation && (
              <Marker
                position={donorLocation}
                label={{ text: "Donor", color: "white", fontWeight: "bold" }}
                icon={{
                  url: "http://maps.google.com/mapfiles/ms/icons/green-dot.png",
                  scaledSize: new window.google.maps.Size(40, 40),
                }}
              />
            )}

            {/* 🔴 Recipient marker */}
            {recipientLocation && (
              <Marker
                position={recipientLocation}
                label={{ text: "Recipient", color: "white", fontWeight: "bold" }}
                icon={{
                  url: "http://maps.google.com/mapfiles/ms/icons/red-dot.png",
                  scaledSize: new window.google.maps.Size(40, 40),
                }}
              />
            )}

            {/* 🔗 Solid red route (Donor → Recipient) */}
            {donorLocation && recipientLocation && (
              <Polyline
                path={[donorLocation, recipientLocation]}
                options={{
                  strokeColor: "#FF0000",
                  strokeOpacity: 0.9,
                  strokeWeight: 4,
                }}
              />
            )}

            {/* 🔵 Dashed blue route (Volunteer → Donor) */}
            {currentLocation && donorLocation && (
              <Polyline
                path={[currentLocation, donorLocation]}
                options={{
                  strokeColor: "#4285F4",
                  strokeOpacity: 0.7,
                  strokeWeight: 3,
                  icons: [
                    {
                      icon: { path: "M 0,-1 0,1", strokeOpacity: 1, scale: 3 },
                      offset: "0",
                      repeat: "10px",
                    },
                  ],
                }}
              />
            )}
          </GoogleMap>
        </LoadScript>

        {!currentLocation && !trackingError && (
          <p className="text-sm text-muted-foreground text-center">
            Fetching your live location...
          </p>
        )}
      </CardContent>
    </Card>
  );
}
