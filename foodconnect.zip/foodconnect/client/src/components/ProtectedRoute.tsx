import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import type { UserRole } from "@shared/schema";

interface ProtectedRouteProps {
  children: React.ReactNode;
  allowedRoles?: UserRole[];
  requireAuth?: boolean;
}

export function ProtectedRoute({ children, allowedRoles, requireAuth = true }: ProtectedRouteProps) {
  const { isAuthenticated, user, loading, isEmailVerified, firebaseUser } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (loading) return;

    if (requireAuth && !isAuthenticated) {
      setLocation("/login");
      return;
    }

    // Check if user email is verified using Firebase's emailVerified property
    // Admins bypass email verification
    if (requireAuth && firebaseUser && !isEmailVerified && user?.role !== "admin") {
      setLocation("/verify-email");
      return;
    }

    if (allowedRoles && user && !allowedRoles.includes(user.role)) {
      // Redirect to appropriate dashboard based on role
      const redirectMap: Record<UserRole, string> = {
        donor: "/dashboard/donor",
        recipient: "/dashboard/recipient",
        volunteer: "/dashboard/volunteer",
        admin: "/dashboard/admin",
      };
      setLocation(redirectMap[user.role] || "/");
    }
  }, [isAuthenticated, user, loading, isEmailVerified, firebaseUser, requireAuth, allowedRoles, setLocation]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (requireAuth && !isAuthenticated) {
    return null;
  }

  if (allowedRoles && user && !allowedRoles.includes(user.role)) {
    return null;
  }

  return <>{children}</>;
}
