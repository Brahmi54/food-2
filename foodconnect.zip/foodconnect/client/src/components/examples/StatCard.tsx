import StatCard from '../StatCard'
import { Heart } from 'lucide-react'

export default function StatCardExample() {
  return (
    <div className="max-w-xs">
      <StatCard
        icon={Heart}
        value="1,234"
        label="Total Donations"
        trend="+12%"
        color="text-primary"
      />
    </div>
  )
}
