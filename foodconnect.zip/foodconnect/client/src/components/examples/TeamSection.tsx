import TeamSection from '../TeamSection'

export default function TeamSectionExample() {
  return <TeamSection />
}
