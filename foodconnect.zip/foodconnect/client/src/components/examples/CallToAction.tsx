import CallToAction from '../CallToAction'

export default function CallToActionExample() {
  return <CallToAction />
}
