import DonationCard from '../DonationCard'

export default function DonationCardExample() {
  return (
    <div className="max-w-sm">
      <DonationCard
        id="1"
        foodType="Fresh Vegetable Meals"
        quantity="50 servings"
        location="Downtown Restaurant, Mumbai"
        expiresIn="2 hours"
        status="available"
        donorName="Green Valley Restaurant"
        onRequest={() => console.log('Request donation clicked')}
      />
    </div>
  )
}
