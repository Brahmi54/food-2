import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { UserPlus, Heart, Users } from "lucide-react";

export default function CallToAction() {
  return (
    <section className="py-16 md:py-20 lg:py-24">
      <div className="container mx-auto max-w-7xl px-4">
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary via-secondary to-accent p-1">
          <div className="rounded-xl bg-background p-8 md:p-12 lg:p-16">
            <div className="text-center space-y-8">
              <h2 className="font-display font-bold text-3xl md:text-4xl lg:text-5xl">
                Ready to Make a Difference?
              </h2>
              <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                Join thousands of donors, volunteers, and recipients working together to reduce food waste and feed communities
              </p>
              
              <div className="grid md:grid-cols-3 gap-4 max-w-4xl mx-auto pt-4">
                <Link href="/register?role=donor">
                  <Button size="lg" variant="outline" className="w-full h-auto py-6 flex flex-col gap-2 hover-elevate" data-testid="button-cta-donor">
                    <Heart className="h-6 w-6 text-primary" />
                    <span className="font-semibold">Become a Donor</span>
                    <span className="text-xs text-muted-foreground font-normal">Share surplus food</span>
                  </Button>
                </Link>
                
                <Link href="/register?role=volunteer">
                  <Button size="lg" variant="outline" className="w-full h-auto py-6 flex flex-col gap-2 hover-elevate" data-testid="button-cta-volunteer">
                    <Users className="h-6 w-6 text-secondary" />
                    <span className="font-semibold">Volunteer Today</span>
                    <span className="text-xs text-muted-foreground font-normal">Coordinate deliveries</span>
                  </Button>
                </Link>
                
                <Link href="/register?role=recipient">
                  <Button size="lg" variant="outline" className="w-full h-auto py-6 flex flex-col gap-2 hover-elevate" data-testid="button-cta-recipient">
                    <UserPlus className="h-6 w-6 text-accent" />
                    <span className="font-semibold">Request Food</span>
                    <span className="text-xs text-muted-foreground font-normal">Get assistance</span>
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
