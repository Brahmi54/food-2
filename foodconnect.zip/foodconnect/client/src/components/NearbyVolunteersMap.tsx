import { useState, useEffect } from "react";
import { GoogleMap, LoadScript, Marker, InfoWindow } from "@react-google-maps/api";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { MapPin, User, AlertCircle } from "lucide-react";
import { getNearbyVolunteers } from "@/lib/firestore";
import { useAuth } from "@/contexts/AuthContext";
import type { User as UserType } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

const mapContainerStyle = {
  width: "100%",
  height: "450px",
  borderRadius: "0.5rem",
};

export default function NearbyVolunteersMap() {
  const { user } = useAuth();
  const [volunteers, setVolunteers] = useState<UserType[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedVolunteer, setSelectedVolunteer] = useState<UserType | null>(null);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);

  // Get user's current location
  useEffect(() => {
    if (!navigator.geolocation) return;

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setUserLocation({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        });
      },
      (error) => {
        console.error("Error getting user location:", error);
      }
    );
  }, []);

  // Fetch nearby volunteers
  useEffect(() => {
    const fetchVolunteers = async () => {
      try {
        setLoading(true);
        const nearbyVols = await getNearbyVolunteers();
        setVolunteers(nearbyVols);
        setError(null);
      } catch (err) {
        console.error("Error fetching volunteers:", err);
        setError("Failed to load nearby volunteers");
      } finally {
        setLoading(false);
      }
    };

    fetchVolunteers();

    // Refresh every 30 seconds
    const interval = setInterval(fetchVolunteers, 30000);
    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return (
      <Card data-testid="card-volunteers-map">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5 text-primary" />
            Nearby Volunteers
          </CardTitle>
          <CardDescription>Real-time volunteer locations for delivery coordination</CardDescription>
        </CardHeader>
        <CardContent>
          <Skeleton className="h-[450px] w-full rounded-md" />
        </CardContent>
      </Card>
    );
  }

  // Calculate map center - use user location or first volunteer location or default
  const mapCenter = userLocation || 
    (volunteers.length > 0 && volunteers[0].location) || 
    { lat: 17.385044, lng: 78.486671 }; // Default to Hyderabad

  return (
    <Card data-testid="card-volunteers-map">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MapPin className="h-5 w-5 text-primary" />
          Nearby Volunteers
        </CardTitle>
        <CardDescription>
          Real-time volunteer locations for delivery coordination
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {volunteers.length === 0 ? (
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              No volunteers are currently available with location tracking enabled.
            </AlertDescription>
          </Alert>
        ) : (
          <Alert>
            <User className="h-4 w-4" />
            <AlertDescription>
              Showing {volunteers.length} volunteer{volunteers.length !== 1 ? "s" : ""} with live location tracking
            </AlertDescription>
          </Alert>
        )}

        {/* Map Legend */}
        <div className="flex flex-wrap gap-4 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-blue-500"></div>
            <span>Volunteer</span>
          </div>
          {userLocation && (
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-red-500"></div>
              <span>Your Location</span>
            </div>
          )}
        </div>

        <LoadScript googleMapsApiKey={import.meta.env.VITE_GOOGLE_MAPS_API_KEY}>
          <GoogleMap
            mapContainerStyle={mapContainerStyle}
            center={mapCenter}
            zoom={12}
          >
            {/* User's location marker */}
            {userLocation && (
              <Marker
                position={userLocation}
                title="Your Location"
                icon={{
                  url: "http://maps.google.com/mapfiles/ms/icons/red-dot.png",
                }}
              />
            )}

            {/* Volunteer markers */}
            {volunteers.map((volunteer) => {
              if (!volunteer.location) return null;
              
              return (
                <Marker
                  key={volunteer.id}
                  position={volunteer.location}
                  title={volunteer.name}
                  onClick={() => setSelectedVolunteer(volunteer)}
                  icon={{
                    url: "http://maps.google.com/mapfiles/ms/icons/blue-dot.png",
                  }}
                />
              );
            })}

            {/* Info Window for selected volunteer */}
            {selectedVolunteer && selectedVolunteer.location && (
              <InfoWindow
                position={selectedVolunteer.location}
                onCloseClick={() => setSelectedVolunteer(null)}
              >
                <div className="p-2">
                  <h3 className="font-semibold">{selectedVolunteer.name}</h3>
                  <p className="text-sm text-gray-600">{selectedVolunteer.phone}</p>
                  <p className="text-xs text-gray-500 mt-1">
                    {selectedVolunteer.address || "Address not available"}
                  </p>
                </div>
              </InfoWindow>
            )}
          </GoogleMap>
        </LoadScript>
      </CardContent>
    </Card>
  );
}
