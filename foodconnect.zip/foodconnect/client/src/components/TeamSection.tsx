import { Avatar, AvatarFallback } from "@/components/ui/avatar";

const team = [
  {
    initials: "BV",
    name: "Brahmaiah Vallepu",
    title: "Founder & CEO",
    bio: "With over 5 years in the food industry, Brahmi founded Food Connect to address the critical issue of food waste and hunger.",
    gradient: "from-primary to-secondary"
  },
  {
    initials: "NV",
    name: "Naga Sri Varsha Mathamsetti",
    title: "CTO",
    bio: "Varsha leads our technology team, developing innovative solutions to connect food donors with recipients efficiently.",
    gradient: "from-secondary to-accent"
  },
  {
    initials: "AR",
    name: "Sri Anjali Reddy Guduri",
    title: "COO",
    bio: "Anjali ensures smooth operations across our platform, coordinating with partners and optimizing our food distribution network.",
    gradient: "from-accent to-primary"
  }
];

export default function TeamSection() {
  return (
    <section className="py-16 md:py-20 lg:py-24 bg-muted/30">
      <div className="container mx-auto max-w-7xl px-4">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="font-display font-bold text-3xl md:text-4xl mb-4">Our Team</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Meet the dedicated individuals behind Food Connect
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {team.map((member, index) => (
            <div key={index} className="flex flex-col items-center text-center space-y-4 p-6">
              <Avatar className="w-24 h-24">
                <AvatarFallback className={`bg-gradient-to-br ${member.gradient} text-white text-2xl font-semibold`}>
                  {member.initials}
                </AvatarFallback>
              </Avatar>
              
              <div className="space-y-1">
                <h3 className="font-display font-bold text-xl">{member.name}</h3>
                <p className="text-sm font-medium text-primary">{member.title}</p>
              </div>
              
              <p className="text-sm text-muted-foreground leading-relaxed max-w-sm">
                {member.bio}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
