import { Utensils, Users, MapPin, CheckCircle } from "lucide-react";

const steps = [
  {
    icon: Utensils,
    title: "Donate Food",
    description: "Restaurants, hotels, and individuals post surplus food details including quantity, type, and pickup location.",
    color: "text-primary bg-primary/10"
  },
  {
    icon: Users,
    title: "Volunteer Accepts",
    description: "Verified volunteers coordinate pickup and delivery, ensuring safe and timely food distribution.",
    color: "text-secondary bg-secondary/10"
  },
  {
    icon: MapPin,
    title: "Real-Time Tracking",
    description: "Track delivery progress live with Google Maps integration showing location and estimated arrival time.",
    color: "text-accent bg-accent/10"
  },
  {
    icon: CheckCircle,
    title: "Food Reaches Recipients",
    description: "NGOs, shelters, and individuals receive fresh food, reducing waste and alleviating hunger.",
    color: "text-primary bg-primary/10"
  }
];

export default function HowItWorks() {
  return (
    <section className="py-16 md:py-20 lg:py-24">
      <div className="container mx-auto max-w-7xl px-4">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="font-display font-bold text-3xl md:text-4xl mb-4">How It Works</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Our simple four-step process connects donors with recipients efficiently and transparently
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              <div className="flex flex-col items-center text-center space-y-4">
                <div className="relative">
                  <div className={`w-16 h-16 rounded-2xl ${step.color} flex items-center justify-center`}>
                    <step.icon className="h-8 w-8" />
                  </div>
                  <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-background border-2 border-primary flex items-center justify-center">
                    <span className="text-sm font-bold text-primary">{index + 1}</span>
                  </div>
                </div>
                
                <h3 className="font-display font-semibold text-xl">{step.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{step.description}</p>
              </div>
              
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-8 left-[calc(50%+2rem)] w-[calc(100%-4rem)] h-0.5 bg-gradient-to-r from-primary/50 to-transparent" />
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
