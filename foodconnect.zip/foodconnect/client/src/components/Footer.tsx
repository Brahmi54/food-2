import { Link } from "wouter";
import { Heart, Mail, Phone, MapPin } from "lucide-react";

export default function Footer() {
  return (
    <footer className="border-t bg-muted/30">
      <div className="container mx-auto max-w-7xl px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="relative">
                <Heart className="h-5 w-5 text-primary fill-primary" />
                <div className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 bg-secondary rounded-full"></div>
              </div>
              <span className="font-display font-bold text-lg">Food<span className="text-primary">Connect</span></span>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Reducing food waste and alleviating hunger by connecting donors, volunteers, and recipients.
            </p>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Quick Links</h3>
            <nav className="flex flex-col gap-2">
              <Link href="/about">
                <span className="text-sm text-muted-foreground hover:text-primary transition-colors cursor-pointer">About Us</span>
              </Link>
              <Link href="/how-it-works">
                <span className="text-sm text-muted-foreground hover:text-primary transition-colors cursor-pointer">How It Works</span>
              </Link>
              <Link href="/faq">
                <span className="text-sm text-muted-foreground hover:text-primary transition-colors cursor-pointer">FAQ</span>
              </Link>
              <Link href="/contact">
                <span className="text-sm text-muted-foreground hover:text-primary transition-colors cursor-pointer">Contact</span>
              </Link>
            </nav>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Legal</h3>
            <nav className="flex flex-col gap-2">
              <Link href="/privacy">
                <span className="text-sm text-muted-foreground hover:text-primary transition-colors cursor-pointer">Privacy Policy</span>
              </Link>
              <Link href="/terms">
                <span className="text-sm text-muted-foreground hover:text-primary transition-colors cursor-pointer">Terms of Service</span>
              </Link>
            </nav>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Contact</h3>
            <div className="flex flex-col gap-3">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Mail className="h-4 w-4" />
                <span>contact@foodconnect.com</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Phone className="h-4 w-4" />
                <span>+91 9123456780</span>
              </div>
              <div className="flex items-start gap-2 text-sm text-muted-foreground">
                <MapPin className="h-4 w-4 mt-0.5" />
                <span>47/22-2, road no 5, Jubilee Hills, Hyderabad, Telangana 500096</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} FoodConnect. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
