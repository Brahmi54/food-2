import { useEffect, useRef, useState } from "react";
import { GoogleMap, useJsApiLoader, Marker, DirectionsRenderer } from "@react-google-maps/api";
import { Skeleton } from "@/components/ui/skeleton";

interface DeliveryMapProps {
  pickupLocation: {
    lat: number;
    lng: number;
    address: string;
  };
  dropoffLocation: {
    lat: number;
    lng: number;
    address: string;
  };
  onDistanceCalculated?: (distance: string, duration: string) => void;
}

const mapContainerStyle = {
  width: "100%",
  height: "100%",
};

const libraries: ("places" | "geometry")[] = ["places", "geometry"];

export default function DeliveryMap({ pickupLocation, dropoffLocation, onDistanceCalculated }: DeliveryMapProps) {
  const { isLoaded, loadError } = useJsApiLoader({
    googleMapsApiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY || "",
    libraries,
  });

  const [directions, setDirections] = useState<google.maps.DirectionsResult | null>(null);
  const [center, setCenter] = useState({ lat: pickupLocation.lat, lng: pickupLocation.lng });
  const mapRef = useRef<google.maps.Map | null>(null);

  useEffect(() => {
  if (!isLoaded || !pickupLocation || !dropoffLocation) return;

  const timeout = setTimeout(() => {
    const directionsService = new google.maps.DirectionsService();

    directionsService.route(
      {
        origin: pickupLocation,
        destination: dropoffLocation,
        travelMode: google.maps.TravelMode.DRIVING,
      },
      (result, status) => {
        if (status === google.maps.DirectionsStatus.OK && result) {
          setDirections(result);

          const leg = result.routes[0]?.legs[0];
          if (leg && onDistanceCalculated) {
            onDistanceCalculated(leg.distance?.text || "", leg.duration?.text || "");
          }
        } else {
          console.error("Directions request failed:", status);
        }
      }
    );

    // Center map automatically between pickup & dropoff
    const centerLat = (pickupLocation.lat + dropoffLocation.lat) / 2;
    const centerLng = (pickupLocation.lng + dropoffLocation.lng) / 2;
    setCenter({ lat: centerLat, lng: centerLng });
  }, 400); // prevent spamming API calls on fast prop updates

  return () => clearTimeout(timeout);
}, [isLoaded, pickupLocation, dropoffLocation, onDistanceCalculated]);

  const onMapLoad = (map: google.maps.Map) => {
  mapRef.current = map;

  // Fit both pickup and dropoff markers into view
  const bounds = new google.maps.LatLngBounds();
  bounds.extend(pickupLocation);
  bounds.extend(dropoffLocation);
  map.fitBounds(bounds);
};

  if (loadError) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-muted rounded-lg">
        <p className="text-destructive">Error loading maps</p>
      </div>
    );
  }

  if (!isLoaded) {
    return <Skeleton className="w-full h-full rounded-lg" />;
  }

  return (
    <GoogleMap
      mapContainerStyle={mapContainerStyle}
      center={center}
      zoom={12}
      onLoad={onMapLoad}
      options={{
        streetViewControl: false,
        mapTypeControl: false,
        fullscreenControl: true,
      }}
    >
      {!directions && (
        <>
          <Marker
            position={{ lat: pickupLocation.lat, lng: pickupLocation.lng }}
            label="P"
            title={pickupLocation.address}
          />
          <Marker
            position={{ lat: dropoffLocation.lat, lng: dropoffLocation.lng }}
            label="D"
            title={dropoffLocation.address}
          />
        </>
      )}
      
      {directions && <DirectionsRenderer directions={directions} />}
    </GoogleMap>
  );
}
