import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Clock, Package } from "lucide-react";

interface DonationCardProps {
  id: string;
  foodType: string;
  quantity: string;
  location: string;
  expiresIn: string;
  status: "available" | "pending" | "assigned" | "completed" | "cancelled";
  donorName?: string;

  // 👇 Add these new props
  recipientName?: string;
  recipientPhone?: string;
  volunteerName?: string;
  volunteerPhone?: string;

  onRequest?: () => void;
  isRequesting?: boolean;
}


export default function DonationCard({
  id,
  foodType,
  quantity,
  location,
  expiresIn,
  status,
  donorName,
  recipientName,
  recipientPhone,
  volunteerName,
  volunteerPhone,
  onRequest,
  isRequesting = false
}: DonationCardProps) {
  const statusColors = {
    available: "bg-green-500/10 text-green-700 dark:text-green-400",
    pending: "bg-yellow-500/10 text-yellow-700 dark:text-yellow-400",
    assigned: "bg-blue-500/10 text-blue-700 dark:text-blue-400",
    completed: "bg-gray-500/10 text-gray-700 dark:text-gray-400",
    cancelled: "bg-red-500/10 text-red-700 dark:text-red-400"
  };

  return (
    <Card className="hover-elevate" data-testid={`card-donation-${id}`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1">
            <h3 className="font-semibold text-lg mb-1">{foodType}</h3>
            {donorName && <p className="text-sm text-muted-foreground">by {donorName}</p>}
          </div>
          <Badge className={statusColors[status]} data-testid={`badge-status-${id}`}>
            {status}
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-3">
        <div className="flex items-center gap-2 text-sm">
          <Package className="h-4 w-4 text-muted-foreground" />
          <span className="text-foreground">{quantity}</span>
        </div>
        
        <div className="flex items-center gap-2 text-sm">
          <MapPin className="h-4 w-4 text-muted-foreground" />
          <span className="text-foreground">{location}</span>
        </div>
        
        <div className="flex items-center gap-2 text-sm">
          <Clock className="h-4 w-4 text-muted-foreground" />
          <span className="text-foreground">Expires in {expiresIn}</span>
        </div>
        {recipientName && (
  <div className="text-sm text-green-700 dark:text-green-400">
    <strong>Recipient:</strong> {recipientName} ({recipientPhone})
  </div>
)}
{volunteerName && (
  <div className="text-sm text-blue-700 dark:text-blue-400">
    <strong>Volunteer:</strong> {volunteerName} ({volunteerPhone})
  </div>
)}

      </CardContent>
      
      {status === "available" && onRequest && (
        <CardFooter className="pt-0">
          <Button 
            className="w-full" 
            onClick={onRequest}
            disabled={isRequesting}
            data-testid={`button-request-${id}`}
          >
            {isRequesting ? "Requesting..." : "Request This Donation"}
          </Button>
        </CardFooter>
      )}
    </Card>
  );
}
