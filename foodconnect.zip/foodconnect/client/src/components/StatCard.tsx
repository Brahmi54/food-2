import { Card, CardContent } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";

interface StatCardProps {
  icon: LucideIcon;
  value: string;
  label: string;
  trend?: string;
  color?: string;
}

export default function StatCard({ icon: Icon, value, label, trend, color = "text-primary" }: StatCardProps) {
  return (
    <Card className="hover-elevate">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <Icon className={`h-8 w-8 ${color}`} />
          {trend && (
            <span className="text-sm font-medium text-green-600 dark:text-green-400">
              {trend}
            </span>
          )}
        </div>
        <div className="space-y-1">
          <p className="text-3xl font-bold tabular-nums">{value}</p>
          <p className="text-sm text-muted-foreground uppercase tracking-wide">{label}</p>
        </div>
      </CardContent>
    </Card>
  );
}
