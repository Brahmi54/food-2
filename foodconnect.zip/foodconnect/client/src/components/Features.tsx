import { Shield, Bell, MapPin, Users, Clock, Award } from "lucide-react";

const features = [
  {
    icon: Shield,
    title: "Verified Users",
    description: "Email OTP verification ensures authentic donors, volunteers, and recipients on our platform.",
    color: "text-primary"
  },
  {
    icon: MapPin,
    title: "Real-Time Tracking",
    description: "Track food deliveries live with Google Maps showing volunteer location and estimated arrival time.",
    color: "text-secondary"
  },
  {
    icon: Bell,
    title: "Instant Notifications",
    description: "Browser-based alerts keep everyone updated on donation status, requests, and deliveries.",
    color: "text-accent"
  },
  {
    icon: Users,
    title: "Multi-Role System",
    description: "Separate dashboards for donors, volunteers, recipients, and administrators for efficient coordination.",
    color: "text-primary"
  },
  {
    icon: Clock,
    title: "Quick Response",
    description: "Fast coordination between donors and volunteers ensures food reaches recipients while fresh.",
    color: "text-secondary"
  },
  {
    icon: Award,
    title: "Fraud Detection",
    description: "Admin dashboard with monitoring tools to detect and prevent fraudulent activity.",
    color: "text-accent"
  }
];

export default function Features() {
  return (
    <section className="py-16 md:py-20 lg:py-24 bg-muted/30">
      <div className="container mx-auto max-w-7xl px-4">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="font-display font-bold text-3xl md:text-4xl mb-4">Platform Features</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Built with security, transparency, and efficiency at its core
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="p-6 rounded-lg border bg-card hover-elevate">
              <feature.icon className={`h-10 w-10 mb-4 ${feature.color}`} />
              <h3 className="font-display font-semibold text-xl mb-2">{feature.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
