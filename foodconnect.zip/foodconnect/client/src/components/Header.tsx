import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Menu, X, Heart } from "lucide-react";
import { useState } from "react";

export default function Header() {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isActive = (path: string) => location === path;

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between px-4 mx-auto max-w-7xl">
        <Link href="/" className="flex items-center gap-2 hover-elevate rounded-lg px-2 py-1 -ml-2">
          <div className="relative">
            <Heart className="h-6 w-6 text-primary fill-primary" />
            <div className="absolute -top-1 -right-1 w-2 h-2 bg-secondary rounded-full"></div>
          </div>
          <span className="font-display font-bold text-xl">Food<span className="text-primary">Connect</span></span>
        </Link>

        <nav className="hidden md:flex items-center gap-6">
          <Link href="/" data-testid="link-home">
            <span className={`text-sm font-medium transition-colors hover:text-primary cursor-pointer ${isActive('/') ? 'text-primary' : 'text-foreground'}`}>
              Home
            </span>
          </Link>
          <Link href="/about" data-testid="link-about">
            <span className={`text-sm font-medium transition-colors hover:text-primary cursor-pointer ${isActive('/about') ? 'text-primary' : 'text-foreground'}`}>
              About
            </span>
          </Link>
          <Link href="/how-it-works" data-testid="link-how-it-works">
            <span className={`text-sm font-medium transition-colors hover:text-primary cursor-pointer ${isActive('/how-it-works') ? 'text-primary' : 'text-foreground'}`}>
              How It Works
            </span>
          </Link>
          <Link href="/contact" data-testid="link-contact">
            <span className={`text-sm font-medium transition-colors hover:text-primary cursor-pointer ${isActive('/contact') ? 'text-primary' : 'text-foreground'}`}>
              Contact
            </span>
          </Link>
        </nav>

        <div className="hidden md:flex items-center gap-3">
          <Link href="/login">
            <Button variant="ghost" data-testid="button-login">Login</Button>
          </Link>
          <Link href="/register">
            <Button variant="default" data-testid="button-get-started">Get Started</Button>
          </Link>
        </div>

        <button
          className="md:hidden"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          data-testid="button-mobile-menu"
        >
          {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {mobileMenuOpen && (
        <div className="md:hidden border-t bg-background">
          <nav className="flex flex-col gap-4 p-4">
            <Link href="/" onClick={() => setMobileMenuOpen(false)}>
              <span className={`text-sm font-medium ${isActive('/') ? 'text-primary' : 'text-foreground'}`}>Home</span>
            </Link>
            <Link href="/about" onClick={() => setMobileMenuOpen(false)}>
              <span className={`text-sm font-medium ${isActive('/about') ? 'text-primary' : 'text-foreground'}`}>About</span>
            </Link>
            <Link href="/how-it-works" onClick={() => setMobileMenuOpen(false)}>
              <span className={`text-sm font-medium ${isActive('/how-it-works') ? 'text-primary' : 'text-foreground'}`}>How It Works</span>
            </Link>
            <Link href="/contact" onClick={() => setMobileMenuOpen(false)}>
              <span className={`text-sm font-medium ${isActive('/contact') ? 'text-primary' : 'text-foreground'}`}>Contact</span>
            </Link>
            <div className="flex flex-col gap-2 pt-2 border-t">
              <Link href="/login" onClick={() => setMobileMenuOpen(false)}>
                <Button variant="ghost" className="w-full">Login</Button>
              </Link>
              <Link href="/register" onClick={() => setMobileMenuOpen(false)}>
                <Button variant="default" className="w-full">Get Started</Button>
              </Link>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
